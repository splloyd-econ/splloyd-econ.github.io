% Code for separate IRF plots

% Run bespoke colour map
setup_lumap

set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultLegendInterpreter','latex');

n = length(model.varnames);
nHorizon = max(model.hz);

nc = length(model.ctryList);

% one plot per variable
for k = (nc+1):n
    f1 = figure(k-nc)
    hold on;
    grid on;
    set(gca,'GridLineStyle',':')
    
    if forwts == 0      % Domestic-only specification, use red
        % bands 68%
        fill([1:nHorizon, fliplr(1:nHorizon)],...
                [squeeze(model.ub(k,wq,:))' fliplr(squeeze(model.lb(k,wq,:))')],...
                lumap(1,:),'EdgeColor','none','MarkerEdgeColor','none','FaceAlpha',0.3);
        % zero line
        plot(1:nHorizon,zeros(nHorizon,1),'color','k','LineWidth',0.5);
        % irfs
        plot(1:nHorizon,squeeze(model.bQRmed(k,wq,:)),'-','LineWidth',2,'MarkerSize',2.5','color',lumap(1,:),'MarkerFaceColor',lumap(1,:));
    else
        % bands 68%
        fill([1:nHorizon, fliplr(1:nHorizon)],...
                [squeeze(model.ub(k,wq,:))' fliplr(squeeze(model.lb(k,wq,:))')],...
                lumap(2,:),'EdgeColor','none','MarkerEdgeColor','none','FaceAlpha',0.5);
        % zero line
        plot(1:nHorizon,zeros(nHorizon,1),'color','k','LineWidth',0.5);
        % irfs
        plot(1:nHorizon,squeeze(model.bQRmed(k,wq,:)),'-','LineWidth',2,'MarkerSize',2.5','color',lumap(2,:),'MarkerFaceColor',lumap(2,:));
    end
    
        hold off; axis tight; 
        
        xlim([1 nHorizon]);
        set(gca,'XTick',2:2:nHorizon,'FontSize',16,'XTickLabel',cellstr(num2str((2:2:nHorizon)')),'layer','top');
        title(varlong{k},'FontSize',24,'Interpreter','latex');
        
        ylabel('Coefficient (pp)','Interpreter','latex','FontSize',20);
        xlabel('Horizon (Quarters)','Interpreter','latex','FontSize',20);
        
        tightInset=get(gca,'TightInset');
        set(gca,'Position',[tightInset(1:2) [1 1]-(tightInset(3:4)+tightInset(1:2))]);
        
        if saveFig == 1
           saveas(f1,['.\Results\' char(runID) '_Swathe_' char(varnames{k}) '.png'],'png');
        end
end