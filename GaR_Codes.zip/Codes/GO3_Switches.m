% GO3_Switches: File Containing all the Possible Switches for Model
% Variants
%
% Code to Estimate GDP@Risk with Spillovers
% Edited/Extended Simon Lloyd, Ed Manuel & Konstantin Panchev, April 2021

switch runID
        %%  M1: Domestic only model 
        case 'm0_dgdp'
        % Start and end date for the sample
        startT = datenum(1981,01,31);
        endT   = datenum(2018,12,31);

        % Select countries in 'domestic' sample
        ctryList ={'AUS','CAN','DNK','FIN', 'FRA','GER','ITA','NOR','SPAIN','SWE','SWI','UK','USA'}; 
        
        % Options for dependent variable...
            % Which one?
            depvar  = {'GDP'};
            % Standardise y variable? (1 if yes, 0 if no) [default = 0]
            standardy   = 0;
            % Cumulate growth of y in local projection? (1 if yes, 0 if no)
            cumulateY   = 1;
            % Average annual growth of y variable? (1 if yes, 0 if no) [default = 1]
            opt_avg     = 1;
           
        % Options for explanatory variables
            % Which ones?
            varDomnames  = [ctryList, {'g1GDP'}];
            varDomlong  = [ctryList, {'GDP Growth'}];
            % Which to standardise? (1 if yes, 0 if no)
            varDomstd    = [zeros(1,length(ctryList)),1      ];
        
        % Select if there are foreign variables
        forwts = 0;     % 1 if yes, 0 if no
        orthog_domvars = 0; %1 if orthogonalise domestic variables wrt foreign variables, 0 otherwise (NB switches to zero if no foreign variables)

        % If yes, which foreign weights and which foreign countries
        if forwts == 1
            % OPTIONS pppwts, pppwtstv, fwtsfix, xwtsfix, fwtstv, xwtstv
            %forwts_name = 'pppwts';     forwts_dim = 1;     % Fixed PPP-weights are 1-dimensional (as fixed for now) (take out dnk and ire)
            %forwts_name = 'pppwtstv';   forwts_dim = 2;     % Time-varying PPP-weights are 2-dimensional
            %forwts_name = 'fwtsfix';    forwts_dim = 4;      % Fixed bank-exposure weights (nb currently lacking DNK NOR and SWI)
            %forwts_name = 'xwtsfix';    forwts_dim = 4;     % Fixed trade weights
            %forwts_name = 'fwtstv';     forwts_dim = 3;     % Time-varying bank-exposure weights (nb only from 2005; lacking DNK, NOR, SWI)
            forwts_name = 'xwtstv';     forwts_dim = 3;     % Time-varying trade weights (NB lacking BEL before 1999)
            varGlobnames        = {};
            varGloblong         = {};
            varGlobstd          = [];
            ctryGlobList        = ctryList;
        else
            varGlobnames        = {};
            varGloblong         = {};
            varGlobstd          = [];
            ctryGlobList        = ctryList; 
            orthog_domvars      = 0;
        end
        
        % Bootstrap options...
            % A boring one: the bootstrap block size (8 is fine)
            bstOptions.blocksize = 8; 
            % Other options for bootstrap 
            bstOptions.nboot    = 100; % Usually 5000
            bstOptions.ci       = 68;   

        % Define the quantiles and the horizons we care about
        quantiles   = [0.05 0.25 0.5 0.75 0.95];
        hz          = 1:1:20; 
        
        %%  M1: Domestic only model 
        case 'm1_d'
        % Start and end date for the sample
        startT = datenum(1981,01,31);
        endT   = datenum(2018,12,31);
        startOOS = datenum(1995,01,01);
        xGFC = 0;
        % Select countries in 'domestic' sample
        ctryList ={'AUS','CAN','DNK','FIN', 'FRA','GER','ITA','NOR','SPAIN','SWE','SWI','UK','USA'}; 
        
        % Options for dependent variable...
            % Which one?
            depvar  = {'GDP'};
            % Standardise y variable? (1 if yes, 0 if no) [default = 0]
            standardy   = 0;
            % Cumulate growth of y in local projection? (1 if yes, 0 if no)
            cumulateY   = 1;
            % Average annual growth of y variable? (1 if yes, 0 if no) [default = 1]
            opt_avg     = 1;
           
        % Options for explanatory variables
            % Which ones?
            varDomnames  = [ctryList, {'d12c2g','VIX','g1GDP'}];
            varDomlong  = [ctryList, {'Credit-to-GDP 3y Ch.','Volatility','GDP Growth'}];
            % Which to standardise? (1 if yes, 0 if no)
            varDomstd    = [zeros(1,length(ctryList)),1       ,1    ,1      ];
        
        % Select if there are foreign variables
        forwts = 0;     % 1 if yes, 0 if no
        orthog_domvars = 0; %1 if orthogonalise domestic variables wrt foreign variables, 0 otherwise (NB switches to zero if no foreign variables)

        % If yes, which foreign weights and which foreign countries
        if forwts == 1
            % OPTIONS pppwts, pppwtstv, fwtsfix, xwtsfix, fwtstv, xwtstv
            %forwts_name = 'pppwts';     forwts_dim = 1;     % Fixed PPP-weights are 1-dimensional (as fixed for now) (take out dnk and ire)
            %forwts_name = 'pppwtstv';   forwts_dim = 2;     % Time-varying PPP-weights are 2-dimensional
            %forwts_name = 'fwtsfix';    forwts_dim = 4;      % Fixed bank-exposure weights (nb currently lacking DNK NOR and SWI)
            %forwts_name = 'xwtsfix';    forwts_dim = 4;     % Fixed trade weights
            %forwts_name = 'fwtstv';     forwts_dim = 3;     % Time-varying bank-exposure weights (nb only from 2005; lacking DNK, NOR, SWI)
            forwts_name = 'xwtstv';     forwts_dim = 3;     % Time-varying trade weights (NB lacking BEL before 1999)
            varGlobnames        = {};
            varGloblong         = {};
            varGlobstd          = [];
            ctryGlobList        = ctryList;
        else
            varGlobnames        = {};
            varGloblong         = {};
            varGlobstd          = [];
            ctryGlobList        = ctryList; 
            orthog_domvars      = 0;
        end
        
        % Bootstrap options...
            % A boring one: the bootstrap block size (8 is fine)
            bstOptions.blocksize = 8; 
            % Other options for bootstrap 
            bstOptions.nboot    = 100; % Usually 5000
            bstOptions.ci       = 68;   

        % Define the quantiles and the horizons we care about
        quantiles   = [0.05 0.25 0.5 0.75 0.95];
        hz          = 1:1:20; 
        
        %% M2: Foreign-augmented model with trade weighted foreign variables 
        case 'm2_f'
        % Start and end date for the sample
        startT = datenum(1981,01,31);
        endT   = datenum(2018,12,31);
        startOOS = datenum(1995,01,01);
        xGFC = 0;
        % Select countries in 'domestic' sample
        ctryList ={'AUS','CAN','DNK','FIN','FRA','GER','ITA','NOR','SPAIN','SWE','SWI','UK','USA'}; 
        
        % Options for dependent variable...
            % Which one?
            depvar  = {'GDP'};
            % Standardise y variable? (1 if yes, 0 if no) [default = 0]
            standardy   = 0;
               % Cumulate growth of y in local projection? (1 if yes, 0 if no)
            cumulateY   = 1;
            % Average annual growth of y variable? (1 if yes, 0 if no) [default = 1]
            opt_avg     = 1;
           
        % Options for explanatory variables
            % Which ones?
            varDomnames  = [ctryList, {'d12c2g','VIX','g1GDP'}];
            varDomlong  = [ctryList, {'Credit-to-GDP 3y Ch.','Volatility','GDP Growth'}];
            % Which to standardise? (1 if yes, 0 if no)
            varDomstd    = [zeros(1,length(ctryList)),1       ,1    ,1     ];
        
        % Select if there are foreign variables
        forwts = 1;     % 1 if yes, 0 if no
        orthog_domvars = 0; %1 if orthogonalise domestic variables wrt foreign variables, 0 otherwise (NB switches to zero if no foreign variables)

        % If yes, which foreign weights and which foreign countries
        if forwts == 1
            % OPTIONS pppwts, pppwtstv, fwtsfix, xwtsfix, fwtstv, xwtstv
            %forwts_name = 'pppwts';     forwts_dim = 1;     % Fixed PPP-weights are 1-dimensional (as fixed for now) (take out dnk and ire)
            %forwts_name = 'pppwtstv';   forwts_dim = 2;     % Time-varying PPP-weights are 2-dimensional
            %forwts_name = 'fwtsfix';    forwts_dim = 4;      % Fixed bank-exposure weights (nb currently lacking DNK NOR and SWI)
            %forwts_name = 'xwtsfix';    forwts_dim = 4;     % Fixed trade weights
            %forwts_name = 'fwtstv';     forwts_dim = 3;     % Time-varying bank-exposure weights (nb only from 2005; lacking DNK, NOR, SWI)
            forwts_name = 'xwtstv';     forwts_dim = 3;     % Time-varying trade weights (NB lacking BEL before 1999)
            varGlobnames        = {'d12c2g','VIX','g1GDP'};
            varGloblong         = {'For.-wtd. Credit-to-GDP 3y Ch.','For.-wtd. Volatility','For.-wtd. GDP Growth'};
            varGlobstd          = [1       ,1        ,1    ];
            ctryGlobList        = ctryList;
        else
            varGlobnames        = {};
            varGloblong         = {};
            varGlobstd          = [];
            ctryGlobList        = ctryList; 
            orthog_domvars      = 0;
        end
        
        % Bootstrap options...
            % A boring one: the bootstrap block size (8 is fine)
            bstOptions.blocksize = 8; 
            % Other options for bootstrap 
            bstOptions.nboot    = 100; % Usually 5000
            bstOptions.ci       = 68;   

        % Define the quantiles and the horizons we care about
        quantiles   = [0.05 0.25 0.5 0.75 0.95];
        hz          = 1:1:20; %can edit this
        
	
  %% END OF SWITCH
end

%% NO NEED TO EDIT THE BELOW
% -------------------------
bst                 = 1;                % always keep at 1
% Combined vectors (for plotting and other outputs)
temp.Ngv = length(varGlobnames);
if forwts == 0
    varGlobnamesf = {};
else
    for n = 1:temp.Ngv
        varGlobnamesf{n} = ['f' char(varGlobnames(n))];
    end
end
varnames = [varDomnames,varGlobnamesf];    
varlong  = [varDomlong,varGloblong];    
varstd   = [varDomstd,varGlobstd];

% Do some checks
temp.Ndv = length(varDomnames);
temp.Nds = length(varDomstd);
if temp.Ndv ~= temp.Nds
    disp('=======================================================================');
    disp('WARNING: Domestic variable length does not match standardisation vector');
    disp('=======================================================================');
end
temp.Ngs = length(varGlobstd);
if temp.Ngv ~= temp.Ngs
    disp('=====================================================================');
    disp('WARNING: Global variable length does not match standardisation vector');
    disp('=====================================================================');
end
