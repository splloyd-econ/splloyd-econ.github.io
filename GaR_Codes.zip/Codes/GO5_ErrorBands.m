% GO5_ErrorBands: Construct Error Bands GDP@Risk Estimation
%
% Code to Estimate GDP@Risk with Spillovers
% Edited/Extended Simon Lloyd & Ed Manuel, March 2022

% take the median of the bootstaps as the main estimate
model.bQRmed     = median(model.bQRbst,4); % this is the median over the bootstraps so the size is # of variables x # of quantiles x horizon

% Calculate the standard deviations for each variable, horizon and quantile over bootstraps
for i = 1:size(model.bQRbst,1)
    for k = 1:size(model.bQRbst,2)
        for j = 1:size(model.bQRbst,3)
            model.std_bQR(i,k,j) = sqrt(var(model.bQRbst(i,k,j,:)));
        end
    end
end

% Confidence bands plus or minus standard errors
model.lb = model.bQRmed - model.std_bQR ;
model.ub = model.bQRmed + model.std_bQR;
model.lb2 = model.bQRmed - 1.96*model.std_bQR ;
model.ub2 = model.bQRmed + 1.96*model.std_bQR;

% standard error for each variable and horizon
for i = 1:size(model.bOLSbst,1)
    for k = 1:size(model.bOLSbst,2)
        model.std_OLS(i,k) = sqrt(var(model.bOLSbst(i,k,:)));
    end
end

model.lbOLS = model.bOLS - model.std_OLS ;
model.ubOLS = model.bOLS + model.std_OLS;
model.lbOLS2 = model.bOLS - 1.96*model.std_OLS ;
model.ubOLS2 = model.bOLS + 1.96*model.std_OLS;