%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MASTER_GAR: Master File for estimating GDP@Risk models with global 
% vulnerabilites a la Lloyd, Manuel and Panchev (2021)
%
% Code includes has quantile-specific fixed effects, 
% and permits estimation of country-specific quantile regressions
%
% Code estimates, and saves, quantile regressions in-sample only

% Prepared by Simon Lloyd and Ed Manuel, September 2022, for Central Bank
% of Egypt
% simon.lloyd@bankofengland.co.uk and edward.manuel@bankofengland.co.uk
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Housekeeping and file path 
% **************************
clear all; clc; close all;
%addpath(genpath('G:\My Drive\Lloyd-Manuel Work\Teaching\2022_CCBS_Egypt\Codes'))
addpath(genpath('G:\.shortcut-targets-by-id\229\Lloyd-Manuel Work\Teaching\2022_CCBS_Egypt\Codes'))


% A Few Options
% *************
saveFig = 0;    % If 1 save figures, if 0 do not save
saveXls = 0;    % If 1 save Xls, if 0 do not save

    %% 1: LOAD ALL THE DATA (Only need to re-run if dataset updated)
    % =========================================================================

    % Name of the main excel ss we want to load stuff from
    % ----------------------------------------------------
    % DataSource = 'GaRDataRaw';
    % DataSourceFinWeights = 'FinancialWeights';
    % DataSourceTradeWeights = 'ExportWeights';
          
    % Run the code that loadz and save the data
    % GO1_LoadData
    % save('GaRRawData');

    %% 2: CREATE THE VARIABLES YOU WILL NEED FOR ESTIMATION
    % =========================================================================
    % Load the data 
    load('GaRRawData');

    % Name the model you want to run (model should exist as a switch in
    % GO3)
    % *********************************************************************
    runID = 'm1_d';
    
    % Create everything you might need in here
    GO2_ConstructVars

    % Find the runID (all model variants should be defined in GO3)
    % ************************************************************
    GO3_Switches

    % Based on switches, now construct everything for estimation
    GO4_Setup
    
    %% 3: IN-SAMPLE ESTIMATION WITH QUANTILE-SPECIFIC FIXED EFFECTS
    % AS PER ADRIAN ET AL. (2022)
    % =========================================================================
    % Estimate quantile regression
    disp('QR ESTIMATION BEGINNING')
    [model.bQR,model.bQRbst,model.bOLS,model.bOLSbst] = qfe_qr_local_projection(Y_LP,X,quantiles,hz,bst,bstOptions);
    disp('QR ESTIMATION COMPLETED')
    
    % Construct error bands
    GO5_ErrorBands

    % Historical decomps and fitted y values
    % -----------------------------------    
    model.nvars       = length(varnames);    % #variables
    model.nctry       = length(ctryList);    % #countries
    model.nperiods    = size(X,1);           % #periods
    model.nquantiles  = length(quantiles);   % #quantiles
    model.nhors       = length(hz);          % #horizons    
    model.varnames    = varnames;
    model.ctryList    = ctryList;
    model.quantiles   = quantiles;
    model.hz          = hz;
    model.X           = X;
    model.Y_LP        = Y_LP;
    model.dates       = dates;
    model.varlong     = varlong;
    
    % ----------------------------------
    % Use bQRmain which is of dimension #variables x #quantiles x #horizons
    model.HD      = zeros(model.nperiods,model.nvars,model.nctry,model.nquantiles,model.nhors);  
    model.Yfit    = nan(model.nperiods,model.nctry,model.nquantiles,model.nhors);
	for k = 1:model.nhors
        for j = 1:model.nquantiles
            for i=1:model.nctry
            	model.HD(:,:,i,j,k) = X(:,(i*nvars - (nvars-1)):(i*nvars)).*squeeze(model.bQRmed(:,j,k))';
                model.Yfit(:,i,j,k) = sum(model.HD(:,:,i,j,k),2);
            end
        end
    end
    
    %% 4: IN-SAMPLE RESULTS
    % =========================================================================
    %% a) Plot IRFs
    close all
    % Pick quantile
    % *************
    wq = 1; 
    GO6_PlotIRFSwathe

    %% b) Plot QR vs OLS comparison
    close all
    GO7_PlotIRFOLS

    %% c) Plot QRFs
    close all
    % Pick horizon
    % ************
    hor = 8; 
    GO8_PlotQuantiles
    
    %% d) Create Excel Spreadsheets with Historical Decomposition
    close all
    % Choose country
    % **************
    HDctry = 'UK';
    % Choose quantile
    % ***************
    HDq    = 1;
    % Choose horizon
    % **************
    HDh    = 8;
    % Create the HD
    HDexport    = model.HD(:,:,find(strcmp(model.ctryList,HDctry)),HDq,HDh);
    [tY,tM,tD]  = datevec(dates(3:end));
    if saveXls == 1
        xlswrite(['HD_h',num2str(HDh),'_q',num2str(HDq),'_',char(HDctry),'.xlsx'],{'YY','MM','DD'},runID,'A1');
        xlswrite(['HD_h',num2str(HDh),'_q',num2str(HDq),'_',char(HDctry),'.xlsx'],model.varlong,runID,'D1');
        xlswrite(['HD_h',num2str(HDh),'_q',num2str(HDq),'_',char(HDctry),'.xlsx'],[tY,tM,tD],runID,'A2');
        xlswrite(['HD_h',num2str(HDh),'_q',num2str(HDq),'_',char(HDctry),'.xlsx'],HDexport,runID,'D2');
    end
    
    %% 5: SAVE WHOLE WORKSPACE
    % =====================================================================
    close all
    eval([char(runID) '=model;']);
    save(['./Results/' char(runID)],char(runID));
    disp('-------COMPLETE-------');