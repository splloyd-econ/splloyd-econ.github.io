% GO1_LoadData: Load Data for GDP@Risk Estimation

% Code to Estimate GDP@Risk with Spillovers
% Edited/Extended Simon Lloyd & Ed Manuel, April 2021

% NOTE: THIS CAN BE RUN ONCE, WITH OUTPUT STORED IN MAT FILE FOR LATER USE

%% Load regression variables (this is where variable names are defined)
% =========================================================================
% (all variables named *_raw, so can be edited again)
[GDP_raw, GDPtext]                                  = xlsread(DataSource,'RGDP');                   % Real GDP (level)
    GDP_raw(GDP_raw == 0)                                   = NaN;
    
[RTg1GDP_raw, RTg1GDPtext]                          = xlsread(DataSource,'RTg1RGDP');               % Real-time UK GDP qoq (%)
    RTg1GDP_raw(RTg1GDP_raw == 0)                           = NaN;

[c2g_raw, c2gtext]                                  = xlsread(DataSource,'c2g');                    % Credit to GDP (level)
    c2g_raw(c2g_raw == 123456789)                           = NaN;

[hhc2g_raw, hhc2gtext]                              = xlsread(DataSource,'hhc2g');                  % Household Credit to GDP (level)
	hhc2g_raw(hhc2g_raw == 123456789)                       = NaN;

[nfcc2g_raw, nfcc2gtext]                            = xlsread(DataSource,'nfcc2g');                 % NFC Credit to GDP (level)
    nfcc2g_raw(nfcc2g_raw == 123456789)                     = NaN;

[HP_raw, HPtext]                                    = xlsread(DataSource,'HP');                     % Real House Prices (level)
    HP_raw(HP_raw == 123456789)                             = NaN;

[pr_raw, prtext]                                    = xlsread(DataSource,'pr');                     % Prices (level)
    pr_raw(pr_raw == 123456789)                             = NaN;

[d4ir_raw, d4irtext]                                = xlsread(DataSource,'d4ir');                   % Central Bank rate: 1-year change
    d4ir_raw(d4ir_raw == 123456789)                         = NaN;

[Kflows_mrd_raw, Kflows_mrd_text]                   = xlsread(DataSource,'KF (SAAR GDP)');          % Capital Flows MRD baseline - GDP saar
    Kflows_mrd_raw(Kflows_mrd_raw == 123456789)             = NaN;

[Kflows_mrd_new_raw, Kflows_mrd_new_text]           = xlsread(DataSource,'KF (SAAR GDP)_new');      % Capital Flows MRD baseline - GDP saar (updated to 2019q4)
    Kflows_mrd_new_raw(Kflows_mrd_new_raw == 123456789)     = NaN;

[Kflows_new_raw, Kflows_new_text]                   = xlsread(DataSource,'KF (non-SA GDP)_new');    % Capital Flows new specification - non-sa GDP (quaterly level)(updated to 2019q4)
    Kflows_new_raw(Kflows_new_raw == 123456789)             = NaN;

[KflowsQA_raw, KflowsQA_text]                       = xlsread(DataSource,'KflowsQA');               % Capital Flows directly from MRD data
    KflowsQA_raw(KflowsQA_raw == 123456789)                 = NaN;

[CA_raw, CAtext]                                    = xlsread(DataSource,'CA');                     % Current Account
    CA_raw(CA_raw == 123456789)                             = NaN;

[CA_new_raw, CA_new_text]                           = xlsread(DataSource,'CA_new');                 % Current Account (updated to 2019q4)
    CA_new_raw(CA_new_raw == 123456789)                     = NaN;

[Cap_raw, Captext]                                  = xlsread(DataSource,'capital');                % Capital Ratio
    Cap_raw(Cap_raw == 123456789)                           = NaN;

[VIX_raw, VIXtext]                                  = xlsread(DataSource,'VIX');                    % Volatility
    VIX_raw(VIX_raw == 123456789)                           = NaN;

[FCI_raw, FCItext]                                  = xlsread(DataSource,'FCI');                    % In-house FCIs
    FCI_raw(FCI_raw == 123456789)                           = NaN;

[FCI_new_raw, FCI_new_text]                         = xlsread(DataSource,'FCI_new');                % In-house FCIs (with implied from VIX HK and Singapore values)
    FCI_new_raw(FCI_new_raw == 123456789)                    = NaN;

[FCIadr_raw, FCIadrtext]                            = xlsread(DataSource,'FCI_ADR');                % Adrian et al (2022) FCIs
    FCIadr_raw(FCIadr_raw == 123456789)                      = NaN;

[Macropru2_raw, Macropru2text]                      = xlsread(DataSource,'Macropru_2y');            % IMF Macroprudential measure: 2 year rolling sum
    Macropru2_raw(Macropru2_raw == 123456789)               = NaN;

[Macropru3_raw, Macropru3text]                      = xlsread(DataSource,'Macropru_3y');            % IMF Macroprudential measure: 3 year rolling sum
    Macropru3_raw(Macropru3_raw == 123456789)               = NaN;

[Macropru5_raw, Macropru5text]                      = xlsread(DataSource,'Macropru_5y');            % IMF Macroprudential measure: 5 year rolling sum
    Macropru5_raw(Macropru5_raw == 123456789)               = NaN;

[Macroprut_raw, Macropruttext]                      = xlsread(DataSource,'Macropru_total');         % IMF Macroprudential measure: sum since base date
    Macroprut_raw(Macroprut_raw == 123456789)               = NaN;
    
 [LTV_raw, LTVtext]                                 = xlsread(DataSource,'LTV');                    % IMF Macroprudential measure: average LTV limits
    LTV_raw(LTV_raw == 123456789)                           = NaN;
       

[kaopen_raw, kaopentext]                            = xlsread(DataSource,'Macropru_total');         % IMF Macroprudential measure: sum since base date
    kaopen_raw(kaopen_raw == 123456789)                     = NaN;

% Load country fixed effect dummies
[AUS_raw, AUStext]                                  = xlsread(DataSource,'AUS');
[BEL_raw, BELtext]                                  = xlsread(DataSource,'BEL');
[CAN_raw, CANtext]                                  = xlsread(DataSource,'CAN');
[DNK_raw, DNKtext]                                  = xlsread(DataSource,'DNK');
[FIN_raw, FINtext]                                  = xlsread(DataSource,'FIN');
[FRA_raw, FRAtext]                                  = xlsread(DataSource,'FRA');
[GER_raw, GERtext]                                  = xlsread(DataSource,'GER');
[IRE_raw, IREtext]                                  = xlsread(DataSource,'IRE');
[ITA_raw, ITAtext]                                  = xlsread(DataSource,'ITA');
[JAP_raw, JAPtext]                                  = xlsread(DataSource,'JAP');
[NLD_raw, NLDtext]                                  = xlsread(DataSource,'NLD');
[NOR_raw, NORtext]                                  = xlsread(DataSource,'NOR');
[SPAIN_raw, SPAINtext]                              = xlsread(DataSource,'SPAIN');
[SWE_raw, SWEtext]                                  = xlsread(DataSource,'SWE');
[SWI_raw, SWItext]                                  = xlsread(DataSource,'SWI');
[UK_raw,  UKtext]                                   = xlsread(DataSource,'UK');
[USA_raw, USAtext]                                  = xlsread(DataSource,'USA');

%% Load Weights Variables
% =========================================================================
% PPP weights
% -----------
[pppwts_raw, pppwtstext]                            = xlsread(DataSource,'pppwts');                 % Fixed weights (from GVAR dataset)
[pppwtstv_raw, pppwtstvtext]                        = xlsread(DataSource,'pppwtstv');               % Time varying weights (from WEO)

% Trade weights
% -------------
[~,xwts_sheet_name]     = xlsfinfo(DataSourceTradeWeights);

for k = 1:numel(xwts_sheet_name)
  
    % Load xwts_raw as array (i.e. no curly brackets), with dimensions:
    % time x external country x source country
    [temp, xwts_text{k}]  = xlsread(DataSourceTradeWeights,xwts_sheet_name{k}); % read in weights as 3D object
    xwts_raw(:,:,k)       = temp(:,3:end);                                      % take off the first two columns (need to do this cos of how SL set up his s/s)
    clear temp

end

% Bank-exposure weights
% ---------------------
% N.B. No Norway or Denmark; Switzerland exposures only inc ~50% of sample
% Data starts 2005 all countries; some missing values
[~,fwts_sheet_name]=xlsfinfo(DataSourceFinWeights);

for k = 3:numel(fwts_sheet_name)    % Need to skip first two tabs

	% Load xwts_raw as array (i.e. no curly brackets), with dimensions:
    % time x external country x source country
    [temp, fwts_text{k-2}]    = xlsread(DataSourceFinWeights,fwts_sheet_name{k});     % read in weights as 3D object
    fwts_raw(:,:,k-2)         = [nan(size(xwts_raw,1)-size(temp,1),size(temp,2));temp];  % add on empty rows so data starts at correct place (need this cos of how EM set up his s/s)
    clear temp
end;

%% Some Extra Manipulations 
% =========================================================================
% Capital Ratio Changes
Delta_cap_raw                                       = NaN(size(GDP_raw,1),size(GDP_raw,2));
Delta_cap_raw(5:end,:)                              = Cap_raw(5:end,:) - Cap_raw(1:end-4,:);                % 1y change in capital ratio

% Dates
Maindates = xlsread(DataSource,'dates');                         % This tab in the s/s should be in 'special' format for dates, like 5-digit numbers for dates     
