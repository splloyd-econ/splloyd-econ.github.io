% GO4_Setup: File to Set Up variables for Estimation
%
% Code to Estimate GDP@Risk with Spillovers
% Edited/Extended Simon Lloyd, Ed Manuel & Konstantin Panchev, April 2021

%% SELECT THE SAMPLE (T, N and GlobN)
% =========================================================================
    % Take the dates in MATLAB's preferred format
    dates_raw  = x2mdate(Maindates);
    % Select the time range that will be used in estimation
    if xGFC == 1
        selectT = (dates_raw>=startT & dates_raw<=endT2)|(dates_raw>=startT2 & dates_raw<=endT);
    else
        selectT = dates_raw>=startT & dates_raw<=endT;
    end
    dates      = dates_raw(selectT);
    selectOOS = dates_raw>=startOOS & dates_raw<=endT;
    
    % Isolate the relevant sample for Y variable
    [~,selectN]         = ismember(ctryList,GDPtext(1,2:end));

    % Isolate relevant sample for constructing global factor (dont touch these)
    [~,selectXN]        = ismember(ctryList,xwts_text{1}(1,2:end)); 
    [~,selectXGlobN]    = ismember(ctryGlobList,xwts_text{1}(1,2:end));
    [~,selectFN]        = ismember(ctryList,fwts_sheet_name(1,3:end));
    [~,selectFGlobN]    = ismember(ctryGlobList,fwts_text{1}(2,2:end));
    [~,selectGlobN]     = ismember(ctryGlobList,GDPtext(1,2:end));

%% SELECT THE SAMPLE FOR WEIGHTS
% =========================================================================
if forwts==1 %allows you to run domestic spec where you dont have weights for every country

% Trade Weights
% a) Time-Varying
xwts_raw(isnan(xwts_raw))=0;
xwtstv              = xwts_raw(selectT,selectXGlobN,selectXN); 
    % Divide through by sum of rows (inefficient, but hopefully accurate)
    % to make fractions
    for nc = 1:size(xwtstv,3)
       for t = 1:size(xwtstv,1)
           xwtstv(t,:,nc) = xwtstv(t,:,nc)./sum(xwtstv(t,:,nc));
       end
    end
% b) Fixed (average full sample)
[~,RN,SN]           = size(xwtstv);
xwtsfix             = nan(SN,RN);
for s = 1:SN
   xwtsfix(s,:)    = nanmean(xwtstv(:,:,s));
end

% Financial Weights
% a) Time-Varying
fwtstv              = fwts_raw(selectT,selectFGlobN,selectFN);
    % Divide through by sum of rows (inefficient, but hopefully accurate)
    % to make fractions
    for nc = 1:size(fwtstv,3)
       for t = 1:size(fwtstv,1)
           fwtstv(t,:,nc) = fwtstv(t,:,nc)./sum(fwtstv(t,:,nc));
       end
    end
% b) Fixed (average 2005-2018)
[~,RN,SN]           = size(fwtstv);
fwtsfix             = nan(SN,RN);
for s = 1:SN
   fwtsfix(s,:)    = nanmean(fwtstv(:,:,s));
end

% c) Mixed weights
% Fixed xwts(2005 onward)
[~,RN,SN]           = size(xwtstv);
xwtsfixalt             = nan(SN,RN);
for s = 1:SN
   xwtsfixalt(s,:)    = nanmean(xwtstv(41:end,:,s));
end
mixwtsfix=(xwtsfixalt+fwtsfix)/2;

end

%% DEFINE THE VARIABLES
% =========================================================================
% Define the dependent variable
eval([char(depvar) ' = ' char(depvar) '_raw(selectT,selectN);']);
y       = eval([char(depvar)]);
[T,N]   = size(y);

% Define the domestic explanatory variables
Nxdom = length(varDomnames);
for nxdom = 1:Nxdom
    eval([char(varDomnames(nxdom)) ' = ' char(varDomnames(nxdom)) '_raw(selectT,selectN);']);
end

% Define the foreign explanatory variables
Nxglob = length(varGlobnames);
for nxglob = 1:Nxglob
    eval([char(varGlobnames(nxglob)) '_globN = ' char(varGlobnames(nxglob)) '_raw(selectT,selectGlobN);']);
    
    % Create some empty matrices for filling later
    eval(['for' char(varGlobnames(nxglob)) ' = nan(T,N);']);
end

% Combine the explanatory variables into a single X matrix (ordered by
% country, then variable)
X = [];
% Loop over countries
for cc = 1:N
    % Domestic variables
    for nxdom = 1:Nxdom
        if varDomstd(nxdom) == 1
            % If you want to standardise them
            X = [X eval(['standard(' char(varDomnames(nxdom)) '(:,cc));'])];
        else
            % If you don't want to standardise them
            X = [X eval([char(varDomnames(nxdom)) '(:,cc);'])];
        end
    end
    
    % Foreign variables
    if forwts == 1
        % Loop over global variables
        for nxglob = 1:Nxglob
            
            % Construct the weighted variable
            if forwts_dim == 1
                % Create the foreign-weighted variables: for fixed PPP
                % weights (i.e. 1 x N dimensions)
                tempctry = varList(cc);
                [~,selecttemp] = ismember(tempctry,varGlobList);  
                eval(['for' char(varGlobnames(nxglob)) '(:,cc) = ' char(varGlobnames(nxglob)) '_globN(:,1:end ~= selecttemp)*transpose(' char(forwts_name) '(1,1:end ~= selecttemp));'])
            elseif forwts_dim == 2
                % Create the foreign-weighted variables: for time-varying
                % PPP weights (i.e. T x N dimensions)
            	tempctry = varList(cc);
                [~,selecttemp] = ismember(tempctry,varGlobList);    
                eval(['for' char(varGlobnames(nxglob)) '(:,cc) = dot(' char(varGlobnames(nxglob)) '_globN(:,1:end ~= selecttemp),' char(forwts_name) '(:,1:end ~= selecttemp),2);'])
            elseif forwts_dim == 3
                % Create the foreign-weighted variables: for time-varying
                % bilateral weights (i.e. T x RN x SN dimensions)
                eval(['for' char(varGlobnames(nxglob)) '(:,cc) = dot(' char(varGlobnames(nxglob)) '_globN(:,: ),squeeze(' char(forwts_name) '(:,:,cc)),2);'])                
            elseif forwts_dim == 4
                % Create the foreign-weighted variables: for fixed
                % bilateral weights (i.e. T x RN x SN dimensions)
                eval(['for' char(varGlobnames(nxglob)) '(:,cc) = ' char(varGlobnames(nxglob)) '_globN(:,:)*transpose(' char(forwts_name) '(cc,:));'])
            end
            
            if varGlobstd(nxglob) == 1
                % If you want to standardise them
                X = [X eval(['standard(for' char(varGlobnames(nxglob)) '(:,cc));'])];
            else
                % If you don't want to standardise them
                X = [X eval(['for' char(varGlobnames(nxglob)) '(:,cc);'])];
            end
    	end
    end
end

%% Orthogonalise domestic variables (if you want to)
Nxglob = length(varGlobnames);
X_new=X;
nvars=length(varnames);
nctry=length(ctryList);
Nxdom = length(varDomnames)-nctry; %excluding the constants for FE

if orthog_domvars==1
    % SMALL-OPEN ECONOMY ASSUMPTION: Foreign affects Dom contemporaneously,
    % but not vice-versa
    for nc=1:nctry
        for xdom=1:Nxdom
            LHS     = X(:,((xdom+nctry)+(nvars)*(nc-1))); %domestic variable
            RHS     = [ones(length(X(:,1)),1),X(:,((nctry+Nxdom+1)+(nvars)*(nc-1)):((nctry+Nxdom+1)+(nvars)*(nc-1))+(Nxglob-1))]; %constant and foreign variables
            coeffs  = (RHS'*RHS)\(RHS'*LHS); %estimate regression via OLS
            fitted  = RHS*coeffs; %fitted values
            resid   = LHS-fitted; %residuals

            X_new(:,((xdom+nctry)+(nvars)*(nc-1)))=resid;

            clear LHS RHS coeffs fitted resid
        end
    end
elseif orthog_domvars==2
    % MONITORING ASSUMPTION: Domestic affects For contemporaneously, but
    % not vice-versa (i.e. how much does foreign add)
    for nc=1:nctry
        for xglob=1:Nxglob

            LHS     = X(:,((Nxdom+nctry+xglob)+(nvars)*(nc-1))); %domestic variable
            RHS     = [X(:,1),X(:,(nctry+1+(nvars)*(nc-1)):((nctry+Nxdom)+(nvars)*(nc-1)))]; %constant and foreign variables
            coeffs  = (RHS'*RHS)\(RHS'*LHS); %estimate regression via OLS
            fitted  = RHS*coeffs; %fitted values
            resid   = LHS-fitted; %residuals

            X_new(:,((1+Nxdom+xglob)+(nvars)*(nc-1)))=resid;

            clear LHS RHS coeffs fitted resid
        end
    end
else 
    X_new   = X;
end

X = X_new; %commenting out for now in case mistake

%% Calculate Y_LP matrix that varies over horizon and will feed into local projection

% Y_LP will be dimensions # period x # country x #horizon

    nhors=length(hz);
    nperiods=size(X,1);
    Y_LP = NaN (nperiods,nctry,nhors);
     
    % Option 1: don't calculate cumulative growth in Y - ie just shift it along one horizon
    if cumulateY == 0
        
             for hor=1:nhors 
     start=size(y,1)-nperiods+hor+1;
     Y_LP(1:end-hor,:,hor)=y(start:end,:);
     clear start
             end
     
    % Option 2: calculate cumualtive t+h growth
    elseif cumulateY == 1  
        
 for hor=1:nhors
     Y_LP(1:(size(y,1)-hz(hor)),:,hor) = 100.*(log(y(1+hz(hor):end,:)) - log(y(1:end-hz(hor),:)));  % THIS PART CHANGES TO CALCULATE GDP CUMULATIVE GROWTH RATE
     % average annualised growth
     % multiply by 4 to annualise but then divide by how many quarters uses
     % construct the cumulative sum, e.g. if quarterly growth (y_2-y_1)
     % then multiply by 4 but divide by 1. If 2 year growth (y_9-y_1) then
     % multiply by 4 but divide by 8.
     if opt_avg == 1
         Y_LP (:,:,hor) = Y_LP(:,:,hor).*(4/hz(hor));
     end
 end 
    end

%% DO A COUPLE OF CHECKS
if max(max(isnan(X)))~=0 % if there are NaN
    disp('======================================')
    disp('WARNING: There are missing values in x')
    disp('======================================')
end
if size(y,1) ~= size(X,1)
    disp('=============================================')
    disp('WARNING: y and X time dimensions do not align')
    disp('=============================================')
end

