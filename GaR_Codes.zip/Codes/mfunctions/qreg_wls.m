function [bQRwls,bOLS] = qreg_wls(y,X,tau,varargin)

if isempty(varargin)
    tol = 1e-6;
else
    tol = varargin{1};
end

bOLS = X\y;
bQRwls = zeros(length(bOLS),length(tau));

for tt = 1:length(tau)
    
    crit = 1;
    b1 = bOLS;
    
    while crit>tol
        
        b0 = b1;
        res = y-X*b0;
        res(res>0) = (1-tau(tt))*res(res>0);
        res(res<0) = -tau(tt)*res(res<0);
        res(res == 0) = .00000000000001;
        Xaux = (X./res)';
        b1 = inv2(Xaux*X)*Xaux*y;
        
        crit = max(abs(b1-b0));
        
    end
    
    bQRwls(:,tt) = b1;
    
end