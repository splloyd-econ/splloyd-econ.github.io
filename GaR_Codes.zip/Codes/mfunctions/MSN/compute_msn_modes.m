function modeVector = compute_msn_modes(xi,Omega,alpha)
% Computes the vector of modes of the marginal distributions of a 
% multivariate Skew-Normal distribution. The function takes as inputs a vector of 
% location parameters \xi, a variance-covariance matrix \Omega and a vector 
% of shape parameters \alpha. See Analytical 6796643 and references 
% therein. Coded by Andrej Sokol on 6 August 2013.

modeVector = zeros(length(xi),1);

for ii = 1:length(xi)
    [~,alphaBar] = msn_marginal_pdf(0,xi,Omega,alpha,ii);
    modeVector(ii) = compute_msn_marginal_mode(xi(ii),Omega(ii,ii),alphaBar);
end

end

function msnMode = compute_msn_marginal_mode(xi,Omega,alpha)

f = @(x) -msn_pdf(x,xi,Omega,alpha);
bnd1 = compute_msn_mean(xi,Omega,alpha)+2*sqrt(compute_msn_variance(xi,Omega,alpha));
bnd2 = compute_msn_mean(xi,Omega,alpha)-2*sqrt(compute_msn_variance(xi,Omega,alpha));
msnMode = fminbnd(f,bnd2,bnd1);

end