function density = msn_pdf(y,xi,Omega,alpha)
% Computes the density of the multivariate Skew-Normal
% distribution. The function takes as inputs a vector of values y for which
% the density is to be computed, a vector of location parameters \xi, a
% variance-covariance matrix \Omega and a vector of shape parameters
% \alpha. See Analytical 6796643 and references therein. Coded by
% Andrej Sokol on 6 August 2013.

omega = diag(sqrt(diag(Omega)));
f = @(x) 2*mvnpdf(x-xi,0,Omega)*...
    mvncdf(alpha'*(omega\(x-xi)));
% density = 2*mvnpdf(y-xi,0,Omega)*...
%     mvncdf(alpha'*(omega\(y-xi)));

density = cellfun(f,num2cell(y,1))';
end