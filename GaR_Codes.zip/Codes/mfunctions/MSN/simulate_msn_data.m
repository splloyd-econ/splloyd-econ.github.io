function simPaths = simulate_msn_data(xi,Omega,alpha,nSims)
% Simulates data from a multivariate Skew Normal distribution taking
% advantage of the stochastic representation of the msn. See Analytical 
% 6796643 and references therein. Coded by Andrej Sokol on 8 August 2013.

omega = diag(sqrt(diag(Omega)));
delta = (1/sqrt(1+alpha'*(omega\Omega/omega)*alpha))*...
    (omega\Omega/omega)*alpha;
Omegaz = omega\Omega/omega;

OmegaStar = [1 delta';delta Omegaz];

% first draws from the multivariate normal distribution to create sim paths
simPaths = mvnrnd(zeros(length(xi)+1,1),OmegaStar,nSims);
simPaths(~(simPaths(:,1)>0),2:end) = -simPaths(~(simPaths(:,1)>0),2:end);

% then transforms it using our parameters so that the paths reflect
% simulated paths of unemployment
simPaths = repmat(xi',nSims,1)+simPaths(:,2:end)*omega;

end