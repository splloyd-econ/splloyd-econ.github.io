function [xi,Omega,alpha,varargout] = reparametrise_msn(modes,stDevs,skews,Omegaz,powerVec,tolX,tolFun,maxIter)
% Reparameterises the multivariate Skew Normal to match a given vector of
% modes, variances,(mean-mode) skews and a correlation matrix \Omegaz.
% See Analytical 6796643 and references therein.
% Coded by Andrej Sokol on 6 August 2013.

% defines some variables we'll use
N = length(modes);
initCond = [modes;zeros(N,1);ones(N,1)];
tModes = modes;
vars = stDevs.^2;
means = modes+skews;

for ii = 1:2
    % define system of nonlinear equations to solve
    
    F = @(x) [compute_msn_modes(x(1:N),diag(x(2*N+1:end))*...
        Omegaz*diag(x(2*N+1:end)),x(N+1:2*N))-tModes;...
        compute_msn_mean(x(1:N),diag(x(2*N+1:end))*...
        Omegaz*diag(x(2*N+1:end)),x(N+1:2*N))-means;...
        diag(compute_msn_variance(x(1:N),diag(x(2*N+1:end))*...
        Omegaz*diag(x(2*N+1:end)),x(N+1:2*N)))-vars].^powerVec;
    
    % gives you a better initialisation
    if ii == 1
        finit = @(x) F(x).^2;
        initCond = fsolve(finit,initCond,...
            optimset('Display','off'));
        disp = 'off';
    else %for second iteration you start where you ended at, and change some stuff
        initCond = minimiser;
        tolFun = 2*tolFun;
        disp = 'notify';
    end
    
    minimiser = fsolve(F,initCond,...
        optimset('TolFun',10^-tolFun,'ScaleProblem','Jacobian',...
        'TolX',10^-tolX,'MaxFunEval',maxIter,...
        'MaxIter',maxIter,'Display',disp)); 
    
    % changes the curvature for second iteration
    powerVec = max(2,powerVec/2);
    
end

% outputs
xi = minimiser(1:N);
Omega = diag(minimiser(2*N+1:end))*Omegaz*diag(minimiser(2*N+1:end));
alpha = minimiser(N+1:2*N);

% goes back and calculates the modes/uncertainties/skews of the
% distribution we've fitted (as opposed to the modes/uncertainties/skews we
% fed as an input and aimed to reach)
fittedModes = compute_msn_modes(xi,Omega,alpha);
fittedStd = sqrt(diag(compute_msn_variance(xi,Omega,alpha)));
fittedSkew = compute_msn_mean(xi,Omega,alpha)-modes;

% checks: the fitted parameters are compared to the parameters we input and
% aimed to reach. 
varargout{1} = [round(100*(fittedModes-modes))./100 ...
    round(100*(fittedStd-stDevs))./100 ...
    round(100*(fittedSkew-skews))./100];
end
