function [marginalDensity,alphaBar] = msn_marginal_pdf(y,xi,Omega,alpha,component)
% Computes the marginal density of the i-th component of the multivariate Skew-Normal
% distribution. The function takes as inputs a scalar y for which
% the marginal density of the i-th component is to be computed, a vector of location parameters \xi, a
% variance-covariance matrix \Omega, a vector of shape parameters
% \alpha and the index of the component of interest. See Analytical 6796643 and references therein. Coded by
% Andrej Sokol on 6 August 2013.

if length(xi) == 1
    
    marginalDensity = msn_pdf(y,xi,Omega,alpha);
    alphaBar = alpha;

else
    
    index = (1:length(xi))';
    index(1) = component;
    index(component) = 1;
    
    xi = xi(index);
    Omega = Omega(index,index);
    alpha = alpha(index);
    alphaBar = (alpha(1)+Omega(1)\(Omega(1,2:end)*alpha(2:end)))/...
        sqrt(1+alpha(2:end)'*(Omega(2:end,2:end)-Omega(2:end,1)*(Omega(1)\Omega(1,2:end)))*alpha(2:end));
    
    marginalDensity = msn_pdf(y,xi(1),Omega(1),alphaBar);
    
end

end