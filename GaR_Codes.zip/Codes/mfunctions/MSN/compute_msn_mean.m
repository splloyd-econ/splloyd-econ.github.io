function meanVector = compute_msn_mean(xi,Omega,alpha)
% Computes the mean of a random variable distributed according to a 
% multivariate Skew-Normal distribution. The function takes as inputs a vector of 
% location parameters \xi, a variance-covariance matrix \Omega and a vector 
% of shape parameters \alpha. See Analytical 6796643 and references 
% therein. Coded by Andrej Sokol on 6 August 2013.

omega = diag(sqrt(diag(Omega)));
delta = (1/sqrt(1+alpha'*(omega\Omega/omega)*alpha))*...
    (omega\Omega/omega)*alpha;
meanVector = xi+omega*delta*sqrt(2/pi);

end