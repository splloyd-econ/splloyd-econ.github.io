%% Function to solve for normal distribution based on two quantiles

function [mu, sigma] = normal_dist_from_two_quantiles(fittedQuantiles,tau)

if (length(fittedQuantiles)==2)==0
    
    error('Enter exactly two quantiles')
end

z = norminv(tau(1))/norminv(tau(2))

mu =(fittedQuantiles(1) - z*fittedQuantiles(2)) / (1-z)
sigma = (fittedQuantiles(1)-mu)/norminv(tau(1))

end