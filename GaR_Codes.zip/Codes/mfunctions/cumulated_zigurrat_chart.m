function zigY=cumulated_zigurrat_chart(simQuantiles,simProbs,zigX)
%This function constructs the bar positions for a cumulated zigurrat chart.
%
%
%Author: Andrej Sokol

% This function takes as inputs the fan chart band positions in absolute
% form, the probability of the outturn being below each band, and the range
% over which to draw the CDF. 

% intialises the output: each cell holds a cdf
zigY=cell(size(simQuantiles,1),1);


for ii=1:size(simQuantiles,1)
    % initialises the matrix inside the cell for the cdf
    zigY{ii}=repmat(simQuantiles(ii,:),length(zigX),1).^0-1;
    % the leftmost column is just the range which the cdf is drawn over
    zigY{ii}(:,1)=zigX';
    %Assign height based on appartenance to fan chart bands
    for bb=1:size(simQuantiles(ii,:),2)-1
        % where 'bb' indices the different bands of the CDF (ie columns
        % 2-18 of the output zigY)
        
       % first part of the assignment below is logical indicing:
       % values are only assigned to those cells in the 'bb-th' column for
       % which the values in the leftmost column are between the
       % 'bb-th' fan band values.
       
       % second part of the assignment below: the values assigned are the
       % probabilities that the outturn is below the band in question (the
       % bb-th band)
        zigY{ii}((zigX'>simQuantiles(ii,bb)) & (zigX'<simQuantiles(ii,bb+1)),bb+1)=simProbs(ii,bb);
        
        % for the current 'bb-th' band, rowCount is the number of rows which fall
        % within that band
        rowCount = sum(zigY{ii}(:,bb+1)>0);
        roCount = 0;
        
        % up until now each matrix cell for a given bb-th band has the same
        % value, that of the probability of the outturn being below the
        % band in question. the following loop now 'smooths' these out so
        % that instead of having the sharp steps similar to those in the
        % zigg, we have a smooooooooth curve. (this is what the 'rowCount'
        % variable is useful for)
        for ro = 1:length(zigX)
            if zigY{ii}(ro,bb+1)>0
                roCount = roCount+1;
                zigY{ii}(ro,bb+1) = zigY{ii}(ro,bb+1)+roCount*(simProbs(ii,bb+1)-simProbs(ii,bb))/rowCount;
            end
        end
        
    end
end
end

