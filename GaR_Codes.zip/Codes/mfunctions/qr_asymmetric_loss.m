function [u] = qr_asymmetric_loss(y,fittedy,quantiles)

% This calculates the Quantile Regression "asymmetric loss" function, which
% e.g. can be used to calculate quantile scores

u = nan(1,length(quantiles));


for wq=1:length(quantiles)
    
quantile=quantiles(wq);

                    if isnan(y);
                        u(wq)=NaN ;   
                    elseif (y-fittedy(wq))<0;
                        u(wq)=(quantile-1)*(y - fittedy(wq));
                    else
                        u(wq) = quantile*(y-fittedy(wq));
                    end 
end

end
