function  [bQR,bQRbst,lb,ub,bOLS,bOLSbst,lbOLS,ubOLS,gStar,lStar,fittedQR,resQR,fittedQRbst,resQRbst]  = quantile_regression_lasso( y, X, tau,gamma,K,bootstrap,varargin)
%Quantile regression. Low-level quantile regression computation
%   uses linprog as low-level solver. Adaptive LASSO shrinkage, calibrated
%   through 10-fold cross-validation.

bQRbst = [];
lb = [];
ub = [];
bOLSbst = [];
lbOLS = [];
ubOLS = [];
fittedQRbst = [];
resQRbst = [];

[n,m] = size(X);

% grid for lambda, given a grid for gamma (can think of alternative spacing
% if it turns out that the lower bound is highly non-linear in gamma...)
lambdaStep = (n^-.5 - n.^(-(gamma+1)/2))/(2*length(gamma)+2);
lambda= zeros(2*length(gamma),length(gamma));
lambda(1,:) = n.^(-(gamma+1)/2)+lambdaStep;
for ll = 2:2*length(gamma)
    lambda(ll,:) = lambda(ll-1,:)+lambdaStep;
end

cvObjective = zeros([size(lambda) length(tau)]); %matrix of average MAD across folds for each gamma,lambda, tau triplet

% cross-validation step (done for point estimates only)
MADtest = zeros(K,length(tau)); %forecast performance criterion for individual folds
indices = crossvalind('Kfold', n, K);

for gg = 1:length(gamma)
    
    for ll = 1:size(lambda,1)
                
        for ii = 1:K
                
            test = (indices == ii); train = ~test;
         
                bQRtest = qreg_lasso(y(train),X(train,:),tau,repmat(gamma(gg),1,length(tau)),repmat(lambda(ll,gg),1,length(tau)));
                rho = @(x) x.*(kron(tau,ones(length(y(test)),1))-(x<0));
                MADtest(ii,:) = mean(rho(repmat(y(test),1,length(tau))-X(test,:)*bQRtest));
        
        end
            
            cvObjective(ll,gg,:) = mean(MADtest);
            
    end
            
end
    

gStar = zeros(1,length(tau));
lStar = gStar;

for tt = 1:length(tau)
    
    [r,c] = find(cvObjective(:,:,tt) == min(min(cvObjective(:,:,tt))),1,'first');
    gStar(tt) = gamma(c);
    lStar(tt) = lambda(r,c);
    
end

[bQR,bQRw,bOLS] = qreg_lasso(y,X,tau,gStar,lStar);

if bootstrap
    
   if ~isempty(varargin) % rewrite for individual inputs
       
       nBoot = varargin{1}.nboot;
       blockSize = varargin{1}.blocksize;
       ci = varargin{1}.ci;
       
   else
       
       nBoot = 200;
       blockSize = round(length(y).^(1/3));
       ci = 95;
       
   end
   
   bQRbst = NaN([size(bQR) nBoot]);
   bOLSbst = zeros([size(bOLS,1) nBoot]);
   fittedQRbst = NaN(length(y),length(tau),nBoot);
   resQRbst = fittedQRbst;
   
   if nBoot>200
   
       parpool
       
       parfor bb = 1:nBoot
          draw = overlapping_bst([y X], blockSize);
          yTemp = draw(:,1);
          Xtemp = draw(:,2:end);
        
          [bQRbst(:,:,bb),~,bOLSbst(:,bb)] = qreg_lasso(yTemp,Xtemp,tau,gStar,lStar,bQRw);
          resQRbst(:,:,bb) = repmat(y,1,length(tau))-X*bQRbst(:,:,bb);
          fittedQRbst(:,:,bb) = X*bQRbst(:,:,bb);
          
       end
       
       delete(gcp)
       
   else
       
       for bb = 1:nBoot
           
          draw = overlapping_bst([y X], blockSize);
          yTemp = draw(:,1);
          Xtemp = draw(:,2:end);

          [bQRbst(:,:,bb),~,bOLSbst(:,bb)] = qreg_lasso(yTemp,Xtemp,tau,gStar,lStar,bQRw);
          
          resQRbst(:,:,bb) = repmat(y,1,length(tau))-X*bQRbst(:,:,bb);
          fittedQRbst(:,:,bb) = X*bQRbst(:,:,bb);
          
       end
   
   end
    
   lp = (100-ci)/2;
   up = ci+lp;
   lb = prctile(bQRbst,lp,3);
   ub = prctile(bQRbst,up,3);
   lbOLS = prctile(bOLSbst,lp,2);
   ubOLS = prctile(bOLSbst,up,2);
            
end

resQR = repmat(y,1,length(tau))-X*bQR;
fittedQR = X*bQR;

end
