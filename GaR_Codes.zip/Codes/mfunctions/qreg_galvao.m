% debug properly, I changed the number of FE to N from N-1 as I convinced
% myself it should work!

function [etaHat,alphaHat,betaHat,gammaHat] = qreg_galvao(y,X,tau,varargin)
% Galvao Jr., A.F. (2011), Quantile regression for dynamic panel data with fixed effects,
% Journal of Econometrics 164 (2011) 142-157
warning('off')
options = optimoptions('quadprog','Display','off');

[T,N] = size(y);
T = T-1; %(because of lag)
K = length(tau);

if isempty(varargin)
    A = eye(K);%need to do better than that
else
    A = varargin{1};
end
% Prepare matrices: just the panel first, then the whole set of quantiles
% y_it = eta_i + alpha(tau_k)y_it-1 + x_it'beta(tau_k) + w_it'gamma(tau_k)
% as Galvao, we assume x contains a (quantile-specific) intercept. This
% makes sense. Also, we need to think about whether it makes sense to
% standardise the GDP series, otherwise the different volatilities will
% blur the estimates? Also, currently the code only admits one instrument
% per quantile.
yy = y(2:end,:);
yyLag = y(1:end-1,:);

% need to think how to construct W. If there are many quantiles, there
% might be too many lags of y to take for that to make sense. an
% alternative is to also start using lags of individual elements of X.

yy = yy(:);
yyLag = yyLag(:);
XX = squeeze(reshape(permute(X,[1 3 2]),[],size(X,2),1));
XX = XX(2:end,:);
ee = eye(N);
FE = kron(ee,ones(T,1)); %this should be ok and not cause collinearity
XBig = [yyLag XX];
sx = size(XBig,2);
dVec = zeros(K,1);
dVec(1) = 1;
Aeq = kron(diag(dVec),[eye(T*N) -eye(T*N) XBig W(:,1)]);
f = zeros(N+K*(2*T*N+sx+1),1);
f(N+1:N+1+2*T*N) = [tau(1)*ones(T*N,1);(1-tau(1))*ones(T*N,1)];
aIndices = zeros(1,K);
bIndices = zeros(K,sx-1);
cIndices = zeros(1,K);
aIndices(1) = N+2*T*N;
bIndices(1,:) = N+2*T*N+1:N+2*T*N+sx;
cIndices(1) = N+2*T*N+sx+1;
if K>1
    for kk = 2:K
        dVec = zeros(K,1);
        dVec(kk) = 1;
        Aeq = Aeq + kron(diag(dVec),[eye(T*N) -eye(T*N) XBig W(:,kk)]);
        f(N+1+(kk-1)*(2*T*N+sx+1):N+1+(kk-1)*(2*T*N+sx+1)+2*T*N) = ...
            [tau(kk)*ones(T*N,1);(1-tau(kk))*ones(T*N,1)];
        aIndices(kk) = aIndices(kk-1)+2*T*N+sx+1;
        bIndices(kk,:) = aIndices(kk)+1:aIndices(kk)+sx-1;
        cIndices(kk) = cIndices(kk-1)+2*T*N+sx+1;
    end
end
Aeq = [repmat(FE,K,1) Aeq]; %N+K*(2*T*N+sx+1)
beq = repmat(yy,K,1);
H = zeros(size(Aeq));
H(N+1+2*T*N+sx:2*T*N+sx:end,N+1+2*T*N+sx:2*T*N+sx:end) = A;
lb = [-inf*ones(N,1);repmat([zeros(2*T*N,1);-.999999;-inf*ones(sx-1,1); -inf],K,1)];
ub = [ inf*ones(N,1);repmat([inf*ones(2*T*N,1);.999999;inf*ones(sx-1,1); inf],K,1)];
bStar = quadprog(H,f,[],[],Aeq,beq,lb,ub,[],options);
etaHat = bStar(1:N);
alphaHat = bStar(aIndices);
bIndices = bIndices';
betaHat = bStar(bIndices(:));
gammaHat = bStar(cIndices);

end