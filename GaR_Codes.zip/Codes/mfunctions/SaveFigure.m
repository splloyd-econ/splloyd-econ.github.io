function SaveFigure(path,quality)
% =======================================================================
% Saves figure to specified path 
% =======================================================================
% SaveFig(path,quality)
% -----------------------------------------------------------------------
% INPUT
%   - path: path wehere to save the file
% -----------------------------------------------------------------------
% OPTIONAL INPUT
%   - quality: 0 standard, 1 high quality [dflt=0]
% =======================================================================
% Ambrogio Cesa Bianchi, April 2015
% ambrogio.cesabianchi@gmail.com

if ~exist('quality','var')
    quality=0;
set(gca,'Layer','top') % to eliminate the missing axes lines, like in fanchart exercise    
% to save an already plotted chart
set(gcf, 'Windowstyle', 'normal')
set(gcf, 'PaperPositionMode','auto'); %Position plot at left hand corner with width 5 and height 5.
set(gcf, 'PaperOrientation','landscape'); %Set the paper to have width 5 and height 5.
set(gcf,'Position',[55 55 1200 800]);
end

if quality 
    set(gcf, 'Color', 'w');
    
set(gca,'Layer','top') % to eliminate the missing axes lines, like in fanchart exercise    
% to save an already plotted chart
set(gcf, 'Windowstyle', 'normal')
set(gcf, 'PaperPositionMode','auto'); %Position plot at left hand corner with width 5 and height 5.
set(gcf, 'PaperOrientation','landscape'); %Set the paper to have width 5 and height 5.
set(gcf,'Position',[55 55 1200 800]);
% saveas(gcf,fullfile(pwd,['RollingCoefficients_outliers' '.pdf']));

    export_fig(path,'-pdf','-png','-painters')
else
    print('-dpng','-r100',path)
    print('-deps','-r100',path)
    print('-dpdf','-r100',path)
end