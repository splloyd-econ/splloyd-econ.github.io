function [fittedParams, fittedQuantiles] = fit_skewnormal_to_quantiles(lpQuantiles,quantiles,quantilesToFit)
% fits skew-t distribution to quantiles (see
% https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr794.pdf?la=en,
% p.9 and http://azzalini.stat.unipd.it/SN/ for the matlab code and other
% resources. This function allows both exactly-identified and
% over-identified fitting.

if length(quantilesToFit)<4
    
    error('Not enough quantiles to fit parameters')
    
end

horizon = size(lpQuantiles,1);
nQ = length(quantilesToFit);
quantileIdxToFit = find(ismember(quantiles,quantilesToFit));
fittedParams = zeros(horizon,3);
fittedQuantiles = zeros(horizon, nQ);

lb = [-inf 1e-6 -inf];
ub = [inf inf inf];

for hh = 1:horizon
    
    minimand = @(x) sum((lpQuantiles(hh,quantileIdxToFit) - qsn(quantiles(quantileIdxToFit),x(1),x(2),x(3))).^2);
    fittedParams(hh,:) = fmincon(minimand,[0 1 0],[],[],[],[],lb,ub);
    fittedQuantiles(hh,:) = qsn(quantiles(quantileIdxToFit),fittedParams(hh,1),fittedParams(hh,2),fittedParams(hh,3));
    
end


end