function [fittedParams, fittedQuantiles] = fit_skewt_to_quantiles_all(AllQuantiles,quantiles,quantilesToFit,countriesToFit,horsToFit)

% This version takes as inputs quantiles estimated across time, countries
% and horizons

% fits skew-t distribution to quantiles (see
% https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr794.pdf?la=en,
% p.9 and http://azzalini.stat.unipd.it/SN/ for the matlab code and other
% resources. This function allows both exactly-identified and
% over-identified fitting.

if length(quantilesToFit)<4
    
    error('Not enough quantiles to fit parameters')
    
end

%lpQuantiles=squeeze(AllQuantiles(:,countriesToFit,:,horsToFit));


periods = size(AllQuantiles,1);
nQ = length(quantilesToFit);
npoints=100; % how many points to fit PDF to
nctry=length(countriesToFit);
nhor= length(horsToFit); 

quantileIdxToFit = find(ismember(quantiles,quantilesToFit));
fittedParams = zeros(periods,4,nctry,nhor);
fittedQuantiles = zeros(periods, nQ,nctry,nhor);
fittedPDFy=zeros(periods,npoints,nctry,nhor);
fittedMoments=zeros(periods,4,nctry,nhor);

lb = [-inf 1e-6 -inf 1];
%ub = [inf inf inf inf];

ub = [inf inf inf 30];



for ctry=1:length(countriesToFit)
    for hor=1:length(horsToFit)

     lpQuantiles=squeeze(AllQuantiles(:,countriesToFit(ctry),:,horsToFit(hor)));
    
      
        for t = 1:periods
    
    % Set initial conditions to align with PlagMol
    iqn = norminv(0.75) - norminv(0.25);    
    lc0 = AllQuantiles(t,countriesToFit(ctry),3,horsToFit(hor)); %median 
    sc0 = (lpQuantiles(3) - lpQuantiles(2)) / iqn;
    sh0 = 0;
    df0=5;

    % Initial conditions
    X0 = [lc0, sc0, sh0 df0];
            
            
    minimand = @(x) sum((lpQuantiles(t,quantileIdxToFit) - qskt(quantiles(quantileIdxToFit),x(1),x(2),x(3),round(x(4)))).^2);
    %fittedParams(t,:,ctry,hor) = fmincon(minimand,[0 1 0 100],[],[],[],[],lb,ub);
        fittedParams(t,:,ctry,hor) = fmincon(minimand,X0,[],[],[],[],lb,ub);

    fittedParams(t,4,ctry,hor) = round(fittedParams(t,4,ctry,hor));
    
    fittedQuantiles(t,:,ctry,hor) = qskt(quantiles(quantileIdxToFit),fittedParams(t,1,ctry,hor),fittedParams(t,2,ctry,hor),fittedParams(t,3,ctry,hor),fittedParams(t,4,ctry,hor));
    
%     fittedCumulants(t,:,ctry,hor) = skt_cumulants(fittedParams(t,1,ctry,hor),fittedParams(t,2,ctry,hor), fittedParams(t,3,ctry,hor), fittedParams(t,4,ctry,hor));
%     
%     rangeToFit = linspace(min(lpQuantiles(t,:))-6,max(lpQuantiles(t,:))+6,npoints);
%     
%     fittedPDFy(t,:,ctry,hor) = dskt(rangeToFit,fittedParams(t,1,ctry,hor),fittedParams(t,2,ctry,hor),fittedParams(t,3,ctry,hor),fittedParams(t,4,ctry,hor));
%     PDFx(t,:,ctry,hor)= rangeToFit;
%     
%     fittedMoments(t,1,ctry,hor)=fittedCumulants(t,1,ctry,hor);
%     fittedMoments(t,2,ctry,hor)=fittedCumulants(t,2,ctry,hor);
%     fittedMoments(t,3,ctry,hor)=fittedCumulants(t,3,ctry,hor)/(fittedCumulants(t,2,ctry,hor).^(3/2));
%     fittedMoments(t,4,ctry,hor)=fittedCumulants(t,4,ctry,hor)./(fittedCumulants(t,2,ctry,hor).^2)+3;

end
    end
           end

end