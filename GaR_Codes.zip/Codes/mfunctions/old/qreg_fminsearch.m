function [bQR,bOLS] = qreg_fminsearch(y,X,tau)

bOLS = X\y;
bQR = zeros(length(bOLS), length(tau));
options = optimset('TolFun',1e-6,'TolX',1e-6,'MaxFunEvals',10000*length(bOLS),'MaxIter',10000*length(bOLS));


for tt = 1:length(tau)
    
    rho = @(x) x.*(tau(tt)-(x<0));
    bQR(:,tt) = fminsearch(@(b) sum(rho(y-X*b)),bOLS,options);

end

end