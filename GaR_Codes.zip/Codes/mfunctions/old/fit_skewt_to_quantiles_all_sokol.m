function [fittedParams, fittedQuantiles, PDFx, fittedPDFy, fittedMoments, fittedMomentsPM] = fit_skewt_to_quantiles_all_sokol(AllQuantiles,quantiles,quantilesToFit,countriesToFit,horsToFit)

% This version takes as inputs quantiles estimated across time, countries
% and horizons

% fits skew-t distribution to quantiles (see
% https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr794.pdf?la=en,
% p.9 and http://azzalini.stat.unipd.it/SN/ for the matlab code and other
% resources. This function allows both exactly-identified and
% over-identified fitting.

if length(quantilesToFit)<4
    
    error('Not enough quantiles to fit parameters')
    
end

% Preliminaries
periods     = size(AllQuantiles,1);
nQ          = length(quantilesToFit);
npoints     = 400; % how many points to fit PDF to
nctry       = length(countriesToFit);
nhor        = length(horsToFit); 
maxdf       = 100; % what is max for degrees of freedom paramteter (higher = slower run but more robust!) 

quantileIdxToFit    = find(ismember(quantiles,quantilesToFit));
fittedParams        = zeros(periods,4,nctry,nhor);
fittedQuantiles     = zeros(periods,nQ,nctry,nhor);
fittedPDFy          = zeros(periods,npoints,nctry,nhor);
fittedMoments       = zeros(periods,4,nctry,nhor);

% Plagborg-Moller Bounds
% lb = [     -20,     0,   -20,  2];
% ub = [      20,    50,   20, 30];
  
 % Original bounds
 lb = [-inf 1e-6 -inf 1];
 ub = [inf inf inf inf];

options =  optimset('MaxFunEvals',1e+4,'MaxIter',1e+4,'TolX',1e-6,'TolCon',1e-6,'Display','on','Algorithm','interior-point' ,'LargeScale','on');

% Loop over countries
for ctry=1:length(countriesToFit)
    % Loop of horizons
    for hor=1:length(horsToFit)
        % Loop over periods
        for t = 1:periods
            % Fitted Quantiles at the period in question
            lpQuantiles=squeeze(AllQuantiles(t,countriesToFit(ctry),:,horsToFit(hor)));
    
            % Set initial conditions to align with PlagMol
%             iqn = norminv(0.75) - norminv(0.25);    
%             lc0 = AllQuantiles(t,countriesToFit(ctry),3,horsToFit(hor)); %median 
%             sc0 = (lpQuantiles(4) - lpQuantiles(2)) / iqn;              
%             sh0 = 0;
%             df0 = ub(end);
%             X0 = [lc0, sc0, sh0, df0];
            

            %% Solve for the parameters: lsqnonlin

    minimand = @(x) sum((lpQuantiles(quantileIdxToFit)' - qskt(quantiles(quantileIdxToFit),x(1),x(2),x(3),round(x(4)))).^2);
    fittedParams(t,:,ctry,hor) = fmincon(minimand,[0 1 0 100],[],[],[],[],lb,ub);
    fittedParams(t,4,ctry,hor) = round(fittedParams(t,4,ctry,hor));
    
            
            %% Remaining Quantites
            fittedQuantiles(t,:,ctry,hor) = qskt(quantiles(quantileIdxToFit),fittedParams(t,1,ctry,hor),fittedParams(t,2,ctry,hor),fittedParams(t,3,ctry,hor),fittedParams(t,4,ctry,hor));
    
            fittedCumulants(t,:,ctry,hor) = skt_cumulants(fittedParams(t,1,ctry,hor),fittedParams(t,2,ctry,hor), fittedParams(t,3,ctry,hor), fittedParams(t,4,ctry,hor));

            rangeToFit = linspace(min(lpQuantiles(:))-6,max(lpQuantiles(:))+6,npoints);
            deltaYY    = (rangeToFit(end)-rangeToFit(1))/npoints;

            fittedPDFy(t,:,ctry,hor) = dskt(rangeToFit,fittedParams(t,1,ctry,hor),fittedParams(t,2,ctry,hor),fittedParams(t,3,ctry,hor),fittedParams(t,4,ctry,hor));
            PDFx(t,:,ctry,hor)= rangeToFit;
            
            % Previous approach to calculating moments using the cumulants

             fittedMoments(t,1,ctry,hor)=fittedCumulants(t,1,ctry,hor);
             fittedMoments(t,2,ctry,hor)=fittedCumulants(t,2,ctry,hor);
             fittedMoments(t,3,ctry,hor)=fittedCumulants(t,3,ctry,hor)/(fittedCumulants(t,2,ctry,hor).^(3/2));
             fittedMoments(t,4,ctry,hor)=fittedCumulants(t,4,ctry,hor)./(fittedCumulants(t,2,ctry,hor).^2)+3;
            
            % Alternate approach to fitting moments (Plagborg-Moller,
            % 2021):
            
            fittedMomentsPM (t,1,ctry,hor) = sum(PDFx(t,:,ctry,hor).*fittedPDFy(t,:,ctry,hor)*deltaYY);
            fittedMomentsPM (t,2,ctry,hor) = sum(((PDFx(t,:,ctry,hor)-  fittedMomentsPM (t,1,ctry,hor)).^2).*fittedPDFy(t,:,ctry,hor)*deltaYY);
            fittedMomentsPM (t,3,ctry,hor) = sum(((PDFx(t,:,ctry,hor)-  fittedMomentsPM (t,1,ctry,hor)).^3).*fittedPDFy(t,:,ctry,hor)*deltaYY)/(fittedMomentsPM (t,2,ctry,hor)^(3/2));
            fittedMomentsPM (t,4,ctry,hor) = sum(((PDFx(t,:,ctry,hor)-  fittedMomentsPM (t,1,ctry,hor)).^4).*fittedPDFy(t,:,ctry,hor)*deltaYY)/(fittedMomentsPM (t,2,ctry,hor)^(2));


        end
    end
end

end

function dist = DistST(X,QQ,qqTarg);
location = X(1);
scale = X(2);
shape = X(3);
df = round(X(4));

qq = qskt(QQ,location,scale,shape,df);


dist = norm(qq-qqTarg);
end