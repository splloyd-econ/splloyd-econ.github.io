function  [bQR,bQRbst,lb,ub]  = qr_new_iid( y, X, tau,bootstrap,varargin)
%Quantile regression. Low-level quantile regression computation
%   uses fminsearch rather than simplex methods or such. The bootstrap only
%   works correctly for da

bOLS = X\y;
bQR = zeros(length(bOLS), length(tau));
options = optimset('TolFun',1e-6,'TolX',1e-6,'MaxFunEvals',10000*length(bOLS),'MaxIter',10000*length(bOLS));

for tt = 1:length(tau)
    
    rho = @(x) x.*(tau(tt)-(x<0));
    bQR(:,tt) = fminsearch(@(b) sum(rho(y-X*b)),bOLS,options);

end

if bootstrap
    
   if ~isempty(varargin) 
       
       nBoot = varargin{1};
       blockSize = varargin{2};
       ci = varargin{3};
       
   else
       
       nBoot = 200;
       blockSize = round(length(y)/20);
       ci = 95;
       
   end
   
   Xtr = X';
   bQRtr = bQR';
   yFit = bQRtr*Xtr;
   resid = kron(ones(length(tau),1),y')-yFit;
   tauBst = kron(tau',ones(1,length(y)));
   rhoBst = @(x) x.*(tauBst-(x<0));
   
   if nBoot>100
   
       parpool
       opt = statset('UseParallel',true);
       temp = bootstrp(nBoot,@(bootr) fminsearch(@(b) sum(sum(rhoBst(yFit+bootr-b*Xtr))),bQRtr,options),resid,'Options',opt);
       delete(gcp)
       
   else
       
       temp = bootstrp(nBoot,@(bootr) fminsearch(@(b) sum(sum(rhoBst(yFit+bootr-b*Xtr))),bQRtr,options),resid);
   
   end
   
   bQRbst = zeros([size(bQR) nBoot]);
   
   for nn = 1:nBoot
       
       bQRbst(:,:,nn) = reshape(temp(nn,:),size(bQRtr))';
       
   end
   
   lp = (100-ci)/2;
   up = ci+lp;
   lb = prctile(bQRbst,lp,3);
   ub = prctile(bQRbst,up,3);
          
end

end
