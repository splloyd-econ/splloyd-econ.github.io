function [fittedParams, fittedQuantiles] = fit_skewt_to_quantiles(lpQuantiles,quantiles,quantilesToFit,loc)
% fits skew-t distribution to quantiles (see
% https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr794.pdf?la=en,
% p.9 and http://azzalini.stat.unipd.it/SN/ for the matlab code and other
% resources. This function allows both exactly-identified and
% over-identified fitting.

% Manually added option to fix the mode (loc) 

if length(quantilesToFit)<4
    
    error('Not enough quantiles to fit parameters')
    
end

horizon = size(lpQuantiles,1);
nQ = length(quantilesToFit);
quantileIdxToFit = find(ismember(quantiles,quantilesToFit));
fittedParams = zeros(horizon,4);
fittedQuantiles = zeros(horizon, nQ);

lb = [1e-6 -inf 1];
ub = [inf inf inf];

%lb = [-inf 1e-6 -inf 1];
%ub = [inf inf inf inf];

for hh = 1:horizon
    
    minimand = @(x) sum((lpQuantiles(hh,quantileIdxToFit) - qskt(quantiles(quantileIdxToFit),loc,x(1),x(2),round(x(3)))).^2);

    % minimand = @(x) sum((lpQuantiles(hh,quantileIdxToFit) - qskt(quantiles(quantileIdxToFit),x(1),x(2),x(3),round(x(4)))).^2);
    fittedParams(hh,1)=loc;
    fittedParams(hh,2:4) = fmincon(minimand,[1 0 100],[],[],[],[],lb,ub);
    fittedParams(hh,4) = round(fittedParams(hh,4));
    fittedQuantiles(hh,:) = qskt(quantiles(quantileIdxToFit),fittedParams(hh,1),fittedParams(hh,2),fittedParams(hh,3),fittedParams(hh,4));
    
end


end