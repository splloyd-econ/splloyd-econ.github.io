function [bQRLASSO,bQR,bOLS] = qreg_lasso_onelinprog( y, X, tau, gamma,lambda,varargin )

% Adaptive LASSO variant as in Yichao Wu AND Yufeng Liu. Strictly speaking,
% the consistency proofs don't hold here because we have non-iid errors,
% but hopefully bootstrap should take care of that.

warning('off')
options = optimoptions('linprog','Display','off','Algorithm','interior-point');

bOLS = X\y;
n=size(X,1);
m=size(X,2);

if isempty(varargin)
    
    bQR = qreg(y,X,tau);
    
else
    
    bQR = varargin{1};
    
end

bQRLASSO = NaN(size(bQR));

tauLength = length(tau);
varLength = 2*(n+m);

% Equality constraints
Aeq=kron(eye(tauLength),[eye(n) -eye(n) X zeros(n,m)]); %y-xbeta = u-v +0eta
beq=repmat(y,tauLength,1);
% Inequality constraints
Aineq = kron(eye(tauLength),-[zeros(2*m,2*n) [-eye(m) eye(m);eye(m) eye(m)]]); %eta_i-beta_i>=0; eta_i+beta_i>=0
bineq = zeros(2*m*tauLength,1);
% Variable bounds
lb=repmat([zeros(2*n,1);-inf*ones(2*m,1)],tauLength,1);
ub=inf*ones(2*m+2*n,1);

% Objective function weights
f = zeros(varLength*tauLength,1);

for tt = 1:tauLength
    
    % LASSO weights
    w = n*lambda(tt)*abs(bQR(:,tt)).^-gamma(tt);
    f((tt-1)*varLength+1:tt*varLength) = [tau(tt)*ones(n,1);(1-tau(tt))*ones(n,1);zeros(m,1);w];
    
end

[bAux,~,~]=linprog(f,Aineq,bineq,Aeq,beq,lb,ub,options);
    
 for tt = 1:tauLength
        
        bQRLASSO(:,tt)=bAux(tt*varLength-2*m+1:tt*varLength-m);
        
 end
    
bQRLASSO(abs(bQRLASSO)<10e-6) = 0;

end


