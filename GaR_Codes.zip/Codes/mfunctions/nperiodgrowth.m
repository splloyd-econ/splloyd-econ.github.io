function y = nperiodgrowth(x,n)
% Code to construct n-period growth rate of a TxN matrix X

[T,N]           = size(x);
y               = nan(T,N);
y((n+1):end,:)  = 100*((x((n+1):end,:)./x(1:(end-n),:))-1);