function varargout=plot_lp(lpQR,y,dates,colour,varargin)
fontSize = 26;

%% Construct date axis
xData = 1:length(dates);

%% bands
medPos = median(1:size(lpQR,2));
if medPos==floor(medPos)
    fcBands = lpQR(:,[1:medPos-1 medPos+1:end]);
else 
    fcBands = lpQR;
end
fcBands = [repmat(y,1,size(fcBands,2));fcBands];
fcBands(:,2:end) = fcBands(:,2:end)-fcBands(:,1:end-1);

%% Plot area
varargout{1}=figure('units','normalized','outerposition',[0 0.1 1 0.9]);
h = area(xData',fcBands,min(.995*min(min(fcBands)),1.005*min(min(fcBands))),'LineStyle','none');

% Set colormap
colormap([[1,1,1];fan_chart_color_map(colour,size(fcBands,2)/2)]);

% Plot backdata
hold on
k = plot(y,'Color',colour,'LineWidth',2.5);
% if ~isempty(varargin{1})
%    plot(xData,[prevIR;NaN],'Color','b','LineWidth',2.5);
%    %Will need to take care of additional lines with possibly different lengths
% end

%Change ticks
axis tight

set(gca,'XLim',[min(xData),max(xData)],'YAxisLocation','right')
set(gca,'XTick',min(xData):8:max(xData),'XTickLabel',dates(1:8:end))
yLength = get(gca,'YLim');
line([xData(length(y)),xData(length(y))],yLength,'Color','k')
legend([k h],{'Actual data','Conditional quantiles'},'Location','southoutside','Orientation','horizontal','FontSize',fontSize)
% ylabel('Percentage Points')
optfont = FigFontOption(fontSize); optfont.title_weight = 'bold'; FigFont(optfont);

if ~isempty(varargin{1})
   
    SaveFigure(varargin{1},0);

end

end