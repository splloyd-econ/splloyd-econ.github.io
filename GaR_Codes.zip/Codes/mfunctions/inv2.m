function mInv = inv2(m)

mInv = m\eye(size(m));

end