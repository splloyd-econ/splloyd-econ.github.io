function [lpQR,lpQRbst,bQR,bQRbst,bOLS,bOLSbst] = qr_local_projection_wls(y,X,tau,hz,bootstrap,varargin)
%note: think about how to do the bootstrap (presumably will need
% some way of weighting the individual draws if I bootstrap, e.g. take mean?)
% X contains regressors with a plausibly contemporaneous relationship with
% y, i.e. what you would use for a nowcast. For example, y(-1) will be in
% X(0), as will be monthly series from the current quarter.

if length(hz) == 1
    horizon = hz;
    counter = 0:hz;
else
    horizon = length(hz);
    counter = [0 hz];
end

bQR = zeros(size(X,2),length(tau),horizon+1);
lpQR = zeros(horizon+1,length(tau));
bOLS = zeros(size(X,2),horizon+1);
nX = size(X,2);

if bootstrap
    
   if ~isempty(varargin) % rewrite for individual inputs
       
       nBoot = varargin{1}.nboot;
       bst = 1;
       blockSize = varargin{1}.blocksize;
       
   else
       
       nBoot = 200;
       bst = 0;
       
       
   end

    bQRbst = zeros(size(X,2),length(tau),horizon+1,nBoot);
    bOLSbst = zeros(size(X,2),horizon+1,nBoot);
    lpQRbst = zeros(horizon+1,length(tau),nBoot);

else
    
    bQRbst = [];
    lpQRbst = [];
    bOLSbst = [];
    
end

Xestim = X(1:length(y),:); %excludes Q0 X data from estimation sample

Xdraws = cell(nBoot,1);
yDraws = Xdraws;
yDrawsFull = yDraws;
XdrawsFull = yDraws;

for nn = 1:nBoot
    
    draw = overlapping_bst([y Xestim], blockSize);
    Xtemp = draw(:,2:end);
    
    while rank(Xtemp)<nX
        
        draw = overlapping_bst([y Xestim], blockSize);
        Xtemp = draw(:,2:end);
        
    end
    
    yDrawsFull{nn} = draw(:,1);
    XdrawsFull{nn} = Xtemp;
    
end

for hh = 0:horizon % 0 is current quarter, i.e. a nowcast. 
    
   yy = y(1+counter(hh+1):end);
   XX = Xestim(1:end-counter(hh+1),:);
  
   for nn = 1:nBoot
   
       yDraws{nn} = yDrawsFull{nn}(1+counter(hh+1):end);
       Xdraws{nn} = XdrawsFull{nn}(1:end-counter(hh+1),:);
       
   end
   
   if bootstrap
   
       if bst
           
           [bQR(:,:,hh+1),bQRbst(:,:,hh+1,:),~,~,bOLS(:,hh+1),bOLSbst(:,hh+1,:)]  = quantile_regression_wls( yy, XX, tau,bootstrap,varargin{1});%,yDraws,Xdraws);
           
       else
           
           [bQR(:,:,hh+1),bQRbst(:,:,hh+1,:),~,~,bOLS(:,hh+1),bOLSbst(:,hh+1,:)]  = quantile_regression_wls( yy, XX, tau,bootstrap);
           
       end
       
   lpQR(hh+1,:) = X(end,:)*bQR(:,:,hh+1);
   
   for bb = 1:nBoot
   
       lpQRbst(hh+1,:,bb) = X(end,:)*bQRbst(:,:,hh+1,bb);
       
   end
   
   else
       
       [bQR(:,:,hh+1),~,~,~,bOLS(:,hh+1)]  = quantile_regression_wls( yy, XX, tau,bootstrap);
       lpQR(hh+1,:) = X(end,:)*bQR(:,:,hh+1);

   end
   
end

if size(X,1) == size(Xestim,1)
    
    lpQR(1,:) = y(end);
    lpQRbst(1,:,:) = y(end);
    
end

end