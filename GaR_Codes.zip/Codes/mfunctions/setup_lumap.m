% Matlab Color Map
% London Underground

lumap   = [220 36  31 ;    % 1 Central
           0   25  168;    % 2 Piccadilly
           0   125 50 ;    % 3 District
           0   0   0  ;    % 4 Northern
           178 99  0  ;    % 5 Bakerloo
           255 211 41 ;    % 6 Circle
           155 0   88 ;    % 7 Metropolitan
           244 169 190;    % 8 H&C
           161 165 167;    % 9 Jubilee
           0   152 216;    % 10 Victoria
           147 206 186;    % 11 Waterloo & City
           239 123 16 ;    % 12 Overground
           0   175 173;    % 13 DLR
           0   189 25 ];   % 14 Trams
lumap   = lumap/255;       
           
           