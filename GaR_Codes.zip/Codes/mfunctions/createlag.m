function y = createlag(x)
% Function to create 1-period lagged version of the TxN matrix x
[T,N] = size(x);
y     = nan(T,N);
y(2:end,:) = x(1:end-1,:);      % Make yday's growth rate relevant for today