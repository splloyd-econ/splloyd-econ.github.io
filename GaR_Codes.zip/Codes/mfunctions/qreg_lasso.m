function [bQRLASSO,bQR,bOLS] = qreg_lasso( y, X, tau, gamma,lambda,varargin )

% Adaptive LASSO variant as in Yichao Wu AND Yufeng Liu. Strictly speaking,
% the consistency proofs don't hold here because we have non-iid errors,
% but hopefully bootstrap should take care of that.

warning('off')
options = optimoptions('linprog','Display','off','Algorithm','interior-point');

bOLS = X\y;
n=size(X,1);
m=size(X,2);

if isempty(varargin)
    
    bQR = qreg(y,X,tau);
    
else
    
    bQR = varargin{1};
    
end

bQRLASSO = NaN(size(bQR));

% Equality constraints
Aeq=[eye(n) -eye(n) X zeros(n,m)]; %y-xbeta = u-v +0eta
beq=y;
% Inequality constraints
Aineq = -[zeros(2*m,2*n) [-eye(m) eye(m);eye(m) eye(m)]]; %eta_i-beta_i>=0; eta_i+beta_i>=0
bineq = zeros(2*m,1);
% Variable bounds
lb=[zeros(2*n,1);-inf*ones(2*m,1);];
ub=inf*ones(2*m+2*n,1);

for tt = 1:length(tau)
    
    w = n*lambda(tt)*abs(bQR(:,tt)).^-gamma(tt);
    w(isnan(w)) = n*lambda(tt)*(10e-6).^-gamma(tt); %to hopefully avoid annoying situations
    f=[tau(tt)*ones(n,1);(1-tau(tt))*ones(n,1);zeros(m,1);w];
    [bAux,~,~]=linprog(f,Aineq,bineq,Aeq,beq,lb,ub,options);
    
    if ~isempty(bAux)
        
        bQRLASSO(:,tt)=bAux(end-2*m+1:end-m);
        
    end
    
end

bQRLASSO(abs(bQRLASSO)<10e-6) = 0;

end
