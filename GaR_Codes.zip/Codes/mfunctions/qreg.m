function [ bQR,bOLS ] = qreg( y, X, tau )

warning('off')
bOLS = X\y;

options = optimoptions('linprog','Display','off','Algorithm','interior-point');
n=size(X,1);
m=size(X,2);
Aeq=[eye(n),-eye(n),X]; %y-xb = u-v
beq=y;
lb=[zeros(2*n,1);-inf*ones(m,1)];
ub=inf*ones(m+2*n,1);

bQR = NaN(m,length(tau));

% Solve the linear programme
for tt = 1:length(tau)
    f=[tau(tt)*ones(n,1);(1-tau(tt))*ones(n,1);zeros(m,1)];
    [bAux,~,~]=linprog(f,[],[],Aeq,beq,lb,ub,options);
    if ~isempty(bAux)
    bQR(:,tt)=bAux(end-m+1:end);
    end
end

end