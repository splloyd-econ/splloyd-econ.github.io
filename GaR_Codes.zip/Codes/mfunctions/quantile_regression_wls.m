function  [bQR,bQRbst,lb,ub,bOLS,bOLSbst,lbOLS,ubOLS,fittedQR,resQR,fittedQRbst,resQRbst]  = quantile_regression_wls( y, X, tau,bootstrap,varargin)
%Quantile regression. Low-level quantile regression computation
%   uses linprog as low-level solver.

bQRbst = [];
lb = [];
ub = [];
bOLSbst = [];
lbOLS = [];
ubOLS = [];
fittedQRbst = [];
resQRbst = [];
nX = size(X,2);

[bQR,bOLS] = qreg_wls(y,X,tau);

if length(varargin) == 3
    
    useDraws = 1;
    yDraws = varargin{2};
    Xdraws = varargin{3};
    
else 
    
    useDraws = 0;
    
end

if bootstrap
    
    if ~isempty(varargin{1}) % rewrite for individual inputs
        
        nBoot = varargin{1}.nboot;
        blockSize = varargin{1}.blocksize;
        ci = varargin{1}.ci;
        
    else
        
        nBoot = 200;
        blockSize = round(length(y).^(1/3));
        ci = 95;
        
    end
    
    bQRbst = zeros([size(bQR) nBoot]);
    bOLSbst = zeros([size(bOLS,1) nBoot]);
    fittedQRbst = zeros(length(y),length(tau),nBoot);
    resQRbst = fittedQRbst;
    
    if nBoot>200
             
        parfor bb = 1:nBoot
            
            if useDraws
                
                yTemp = yDraws{bb};
                Xtemp = Xdraws{bb};
                
            else
                
                draw = overlapping_bst([y X], blockSize);
                Xtemp = draw(:,2:end);
                
                while rank(Xtemp)<nX
                    
                    draw = overlapping_bst([y X], blockSize);
                    Xtemp = draw(:,2:end);
                    
                end
                
                yTemp = draw(:,1);
                
            end
            
            [bQRbst(:,:,bb),bOLSbst(:,bb)] = qreg_wls(yTemp,Xtemp,tau);
            fittedQRbst(:,:,bb) = X*bQRbst(:,:,bb);
            resQRbst(:,:,bb) = repmat(y,1,length(tau))-fittedQRbst(:,:,bb);
            
            
        end
        
        
    else
        
        for bb = 1:nBoot
            
            if useDraws
                
                yTemp = yDraws{bb};
                Xtemp = Xdraws{bb};
                
            else
                
                draw = overlapping_bst([y X], blockSize);
                Xtemp = draw(:,2:end);
                
                while rank(Xtemp)<nX
                    
                    draw = overlapping_bst([y X], blockSize);
                    Xtemp = draw(:,2:end);
                    
                end
                
                yTemp = draw(:,1);
                
            end
            
            [bQRbst(:,:,bb),bOLSbst(:,bb)] = qreg_wls(yTemp,Xtemp,tau);
            fittedQRbst(:,:,bb) = X*bQRbst(:,:,bb);
            resQRbst(:,:,bb) = repmat(y,1,length(tau))-fittedQRbst(:,:,bb);
            
            
        end
        
    end
    
    lp = (100-ci)/2;
    up = ci+lp;
    lb = prctile(bQRbst,lp,3);
    ub = prctile(bQRbst,up,3);
    lbOLS = prctile(bOLSbst,lp,2);
    ubOLS = prctile(bOLSbst,up,2);
    
end

fittedQR = X*bQR;
resQR = repmat(y,1,length(tau))-fittedQR;


end
