function [ fittedDist ] = fit_kernel_to_quantiles( targetQuantiles, tau,st,varargin)
% fits kernel density to quantiles

if ~isempty(varargin)
    
    krnl = varargin{1};
    
else
    
    krnl = 'normal';
    
end

%icdf
% objective = @(q)  sum((targetQuantiles-icdf(fitdist(q,'Kernel','Kernel',krnl),tau)).^2);
%cdf
objective = @(q)  sum((tau-cdf(fitdist(q,'Kernel','Kernel',krnl),targetQuantiles)).^2);


if st >= 1 %use fewer parameters

    solution = fmincon(objective,targetQuantiles(1:st:end)',[],[],[],[],[],[],[],optimoptions('fmincon','Display','off'));

else %overparametrise
    
    nrep = max(1,round(1/st));
    solution = fmincon(objective,repmat(targetQuantiles',nrep,1),[],[],[],[],[],[],[],optimoptions('fmincon','Display','off'));

end

fittedDist = fitdist(solution,'Kernel');

end

