function zigY=zigurrat_chart(simQuantiles,simBands,zigX)
%This function constructs the bar positions for a zigurrat chart.
%
%The function takes as inputs the quantiles and fan chart band widths for that
%quarter (both assumed to be 1x18, and the range of values over which to draw
%the zigurrat chart.
%The output is a matrix of heights (if the simulations are expressed in % points,
%then zigY is in the same unit), which can then be plotted against the first column of zigY, for
%example using bar(zigY{1}(:,1),zigY{1}(:,2:end)).
%The colormap can be set using the fan_chart_color_map.m function.
%
%The function can backfire when the underlying pdfr has more than
%one local maximum; in that case, sometimes the
%histograms' height is not decreasing from the centre towards the outside.
%A possible solution, if increasing the number of sims does not do the trick, is
%to use the fitted distribution to construct the quantiles, rather than the sims themselves; 
%this however, will not always be a fair representation of what's going on in the
%simulations.
%
%Author: Andrej Sokol



n = 180/size(simBands,2);
zigY=cell(size(simQuantiles,1),1);

% for each quarter that we make a zig for (including zigs from previous
% IRs)..
for ii=1:size(simQuantiles,1)
    % initialise matrix
    zigY{ii}=repmat(simBands(ii,:),length(zigX),1).^0-1;
    % first column is just the range that the zig is drawn over
    zigY{ii}(:,1)=zigX';   
    %Assign height based on appartenance to fan chart bands
    for bb=1:size(simQuantiles(ii,:),2)-1
        % where bb indices the different bands of the zigg (ie columns 2-18
        % of the output zigY)
        if bb==size(simQuantiles(ii,:),2)/2
            % this applies only to the middle band which is special since
            % it has 10% of probability mass in itself
            % first part of the assignment below is logical indicing:
            % height is only assigned to those cells in the 'bb-th' column for
            % which the values in the leftmost column are between the
            % 'bb-th' fan band values.
            % Second part of the assignment assigns the height based on the
            % width of the 'bb-th' fan chart band
            zigY{ii}((zigX'>simQuantiles(ii,bb)) & (zigX'<simQuantiles(ii,bb+1)),bb+1)=n/(simBands(ii,bb+1));
        else
            % same as above
            zigY{ii}((zigX'>simQuantiles(ii,bb)) & (zigX'<simQuantiles(ii,bb+1)),bb+1)=n/(simBands(ii,bb+1)+simBands(ii,end-bb+1));
        end
    end
end
end