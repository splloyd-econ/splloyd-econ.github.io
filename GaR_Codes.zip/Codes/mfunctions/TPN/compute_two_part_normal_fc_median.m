function fanMedian = compute_two_part_normal_fc_median(fanParams)
% fanMedian function takes as input the parameters for the two-part normal
% probability distribution in each quarter, and computes the median value
% for each quarter


% See comments on reparametrise_two_part_normal function for explanation of
% what this function does - basically converts between two forms of
% parameters
[s1, s2] = reparametrise_two_part_normal(fanParams(:,2),fanParams(:,3));

% Initialises the variable that'll hold the median values for each quarter
dataLength = size(fanParams,1);
fanMedian = zeros(dataLength,1);

% Calculates the median for each quarter by using the inverse cdf function.
% The inverse cdf function takes as inputs the parameters for each quarter
% (and 0.5 as we're looking for the median), and outputs the value of the
% variable that has 50% of the probability mass below it (based on
% simulation). See its comments for more information.
for jj=1:dataLength
    fanMedian(jj) = two_part_normal_inverse_cdf...
        (.5,fanParams(jj,1),s1(jj),s2(jj));
end

end