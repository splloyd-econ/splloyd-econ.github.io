function unc = compute_input_std_of_two_part_normal(skews,stDevs)


if abs(skews)>1.3
    skews = sign(skews)*1.3;
end
vars = stDevs.^2;
s2 = @(s1) sqrt(pi/2)*skews+s1;
varX = @(s1) (1-2/pi).*(s2(s1)-s1).^2+s1.*s2(s1)-vars;
sStar = fsolve(varX,ones(length(skews),1));
unc = sqrt((2*(sStar.^2).*(s2(sStar)).^2)./(sStar.^2+s2(sStar).^2));
end