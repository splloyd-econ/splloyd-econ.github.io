function varargout=compute_two_part_normal_fc_bands(fanParams)
% Computes the band positions needed to plot a standard fanchart (with 9
% pairs of bands) based on the two-part normal distribution,
% and optionally also returns the underlying quantiles.
%
% Author: Andrej Sokol

% Function inputs: three columns of parameters which are, in order, the
% modes, uncertainties, and skews. Each row of the input variable
% corresponds to a quarter

% A two part normal distribution can be desribed in two ways - roughly
% speaking, either with two standard deviations (one for above mode, one
% for below mode) or with a single input uncertainty and a skew. We feed
% matlab the latter but it's easier to work with the former. The following
% line/function converts from the latter to the former. We thus send the
% uncertainties and skews for each quarter, and receive the two standard
% deviations for each quarter.
[s1, s2] = reparametrise_two_part_normal(fanParams(:,2),fanParams(:,3));

% Corresponds to there being 9 pairs of bands
pWeights=1/10:1/10:9/10;

% Creates a column showing, for each quarter, the probability of the
% outturn being below the mode
probsBelowMode = (s1./(s1+s2));

% Number of quarters that the fan chart stretches across (currently 32 for
% the GDP fan since the backcast fan is included too)
dataLength = size(fanParams,1);

% Calculates the third output of this function. A matrix that contains, for
% each quarter, the probability of the outturn being below each fan band.
% Quarters are rows and fan bands are columns. This is easily possible
% since if, eg, 55% of the probability mass is below the mode and thus 45%
% above, each fan band below the mode will have 5.5% (55%/10) probability
% mass in it and each band above will have 4.5% probability mass in it.
% This is a feature of the two part normal distribution.
varargout{1}=zeros(dataLength,18);
varargout{1}(:,1:9)=probsBelowMode*pWeights;
varargout{1}(:,10:18)=repmat(probsBelowMode,1,9)+(1-probsBelowMode)*pWeights;
% if s1=s2=0 there would otherwise be NaNs here
varargout{1}(isnan(varargout{1}(:))) = .5;
varargout{3} = varargout{1};


% Finds the index corresponding to the first quarter where there is a fan
% around the variable in the start, by searching for the first quarter
% where there is a non-zero standard deviation
% to find first non-NaN
fanStartIdx = find(s1,1);
if isempty(fanStartIdx)
    fanStartIdx = dataLength+1;
end

% Begins building the second output of this function. A matrix that shows
% the position of each fan chart band for each quarter. The rows are
% quarters and the columns are positions of the bands (or technically, the
% positions of the edges of the bands for each quarter). There are 18
% columns currently. The two part normal inverse cdf function is used to
% calculate the position of each band (we feed in the third output of this
% function as it is a matrix of the probability that the outturn is below
% each fan chart band in each quarter).
varargout{1}(1:fanStartIdx-1,:) = repmat(fanParams(1:fanStartIdx-1,1),1,18);

for jj=fanStartIdx:dataLength
    varargout{1}(jj,:) = two_part_normal_inverse_cdf...
        (varargout{3}(jj,:),fanParams(jj,1),s1(jj),s2(jj));
end

varargout{2}=varargout{1};

% Calculates the first output of this function: the same as the second but
% in difference form. So if the fan chart band positions for a given
% quarter were [1.1,1.3,1.8,2.0,..] this would transform it into
% [1.1,0.2,0.5,0.2,...] - the first column is the starting the value and
% the rest are the differences
varargout{1}=varargout{1}-[zeros(size(varargout{1},1),1) varargout{1}(:,1:end-1)];

end