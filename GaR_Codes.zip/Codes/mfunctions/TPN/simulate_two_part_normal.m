function simPaths = simulate_two_part_normal(fanParams,nSims)
% This function simulates the two part normal distribution for each quarter
% a given number of times. This function takes as inputs the parameters of 
% the two-part normal distribution for each quarter, and the number of
% times to simulate the distribution in each quarter ('nSims'). It returns
% a matrix of simulations, where each column is a quarter of the fan and
% each row is a simulation.

% See comments on the relevant function for more information. 
[s1, s2] = reparametrise_two_part_normal(fanParams(:,2),fanParams(:,3));

% Initialises the matrix that will hold all sims.
simPaths = zeros(nSims,length(s1));

% For each quarter of the forecast, creates nSims number of sims. The
% 'simulation' part is done by the rand() function which draws a bunch
% ('nSims' being the length of the bunch) of random numbers between 0 and
% 1 (uniformly distributed). These numbers are then passed to the two part normal inverse cdf
% function as the probability masses (see comments on that function for more
% information). The idea behind the random drawing is that a uniform
% distribution is appropriate for drawing the probability values for the
% CDF since by construction there is a 5% chance of getting a value with
% 0-0.05 probability mass below it, a 50% chance of getting a value that has
% 0-0.50 probability mass below it, etc.
for ii = 1:length(s1)
    simPaths(:,ii) = two_part_normal_inverse_cdf(rand(nSims,1),fanParams(ii,1),...
        s1(ii),s2(ii));
end

end