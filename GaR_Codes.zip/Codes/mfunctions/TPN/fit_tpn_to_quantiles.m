function [fittedParams,fittedQuantiles] = fit_tpn_to_quantiles(data,quantiles,weights)

fittedParams = zeros(size(data,1),3);
fittedQuantiles = zeros(size(data));
paramsInit = [0 1 1];

for tt = 1:size(data,1)
    
    distToFit = @(x) (two_part_normal_inverse_cdf(quantiles,x(1),x(2),x(3))-data(tt,:)).*weights;
    temp = fsolve(distToFit,paramsInit,optimset('MaxFunEval',20000,'MaxIter',20000,'TolFun',1e-6,'TolX',1e-20));
    
    fittedParams(tt,1) = temp(1); %mode
    fittedParams(tt,2) = sqrt(2*(temp(2)^2)*(temp(3)^2)/(temp(2)^2+temp(3)^2)); %unc
    fittedParams(tt,3) = sqrt(2/pi)*(temp(3)-temp(2)); %skew
    

    fittedQuantiles(tt,:) = two_part_normal_inverse_cdf(quantiles,...
        fittedParams(tt,1),temp(2),temp(3));
%     paramsInit = temp;

    
end

end