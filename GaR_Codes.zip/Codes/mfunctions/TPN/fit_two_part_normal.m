function varargout=fit_two_part_normal(varargin)

% Fits a two-part Normal distribution to a set of simulated paths, assumed to be of size nSimsxHorizon.
% twistedParams=fit_two_part_normal(simPaths) returns a Hx3 vector of modes
% and sigma1s and sigma2s.
% twistedParams=fit_two_part_normal(simPaths,modeVector) can be used to
% constrain the central projection within the darkest band of a fan chart
% (though statistical tests will usually reject this as a workable
% hypothesis). See Analytical 6650763 for a motivation of this
% functionality.
% [twistedParams,ksTests]=fit_two_part_normal(simPaths,[modeVector]) also
% returns the results of a Kolmogorov-Smirnov test of the null that the
% simulated paths have the same distribution as the fitted one.
%
%Author: Andrej Sokol

% Note that this can be improved using cellfun!!



switch length(varargin)
    case 1
        % (My understanding of this isn't 100% so if you're a matlab expert
        % and you think I've interpreted something wrongly then I probably
        % have). The below line creates the 'two_piece' handle and assigns
        % it to the pdf for the two part normal so that the mle function
        % used later understands what we mean by 'two_piece'
        two_piece=@(X,m,s1,s2) two_part_normal_pdf(X,m,s1,s2);
        varargout{1}=zeros(size(varargin{1},2),3);
        varargout{2}=zeros(size(varargin{1},2),1);
        
        % For each quarter in the input matrix of simulations...
        for h=1:size(varargin{1},2)
            data = varargin{1}(~isnan(varargin{1}(:,h)),h);
            % We create the matrix of parameters (mode, sigma1, sigma2, for
            % each quarter) by using mle estimation along with the two part
            % normal pdf to choose parameters that best match the simulated
            % data that we're feeding in.
            varargout{1}(h,:)=mle(data,'pdf',two_piece,...
                'start',...
                [nanmean(varargin{1}(:,h)) nanstd(varargin{1}(:,h)) nanstd(varargin{1}(:,h))],...
                'lower',[-inf 0 0]);
            %tests whether sims can be reasonably thought of as coming from
            %a two-part Normal: the matrix below should contain mostly zeros;
            %if it doesn't, then probably this procedure is not a great idea
            %for the case at hand (e.g. because the twisting is too extreme)
            varargout{2}(h)=kstest2(varargin{1}(:,h),two_part_normal_inverse_cdf(rand(size(varargin{1},1),1),varargout{1}(h,1),...
                varargout{1}(h,2), varargout{1}(h,3)));
        end
    otherwise
        % Similar to above, but here we're constraining the mode so that
        % mle is only choosing the standard deviations.
        varargout{1}=zeros(size(varargin{1},2),3);
        varargout{2}=zeros(size(varargin{1},2),1);
        for h=1:size(varargin{1},2)
            two_piece=@(X,s1,s2) two_part_normal_pdf(X,varargin{2}(h),s1,s2);
            data = varargin{1}(~isnan(varargin{1}(:,h)),h);
            varargout{1}(h,2:3)=mle(data,'pdf',two_piece,...
                'start',...
                [nanstd(varargin{1}(:,h)) nanstd(varargin{1}(:,h))],...
                'lower',[0 0]);
            varargout{1}(h,1)=varargin{2}(h);
            varargout{2}(h)=kstest2(varargin{1}(:,h),two_part_normal_inverse_cdf(rand(size(varargin{1},1),1),varargout{1}(h,1),...
                varargout{1}(h,2), varargout{1}(h,3)));
        end
end
end