function density = two_part_normal_pdf(x,mode,sigma1,sigma2)
% This function returns the density function for a two part
% normal density

% true/false if x is less than the mode
lessThanMode      = (x<=mode);

% uses the formula to compute the probability density value depending on
% whether x is bigger or smaller than the mode.
density = ...
    2*sigma1/(sigma1+sigma2)*lessThanMode.*normpdf(x,mode,sigma1) + ...
    2*sigma2/(sigma1+sigma2)*(~lessThanMode).*normpdf(x,mode,sigma2); 
