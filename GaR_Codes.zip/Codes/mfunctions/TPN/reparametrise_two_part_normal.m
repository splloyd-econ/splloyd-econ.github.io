function [sigma1,sigma2]=reparametrise_two_part_normal(inputUnc,inputSkew)
% Reparametrises the two-part Normal distribution from the IR
% parametrisation to a more MATLAB-friendly one.
%
%Author: Andrej Sokol

% A two part normal distribution can be desribed in two ways - roughly
% speaking, either with two standard deviations (one for above mode, one
% for below mode) or with a single input uncertainty and a skew. We feed
% matlab the latter but it's easier to work with the former. This
% function converts from the latter to the former. We thus send the
% uncertainties and skews for each quarter, and receive the two standard
% deviations for each quarter.


% The below lines action the formula that converts between the two sets of
% parameters. See Analytical 200365 for more information on the
% distribution used, converting between the two forms, and other references
% for information on this distribution
Gamma=zeros(size(inputUnc));
Gamma(inputSkew>0)=sqrt(1-((sqrt(1+pi*inputSkew(inputSkew>0).^2./inputUnc(inputSkew>0).^2)-1)./(pi*inputSkew(inputSkew>0).^2./(2*inputUnc(inputSkew>0).^2))).^2);
Gamma(inputSkew<0)=-sqrt(1-((sqrt(1+pi*inputSkew(inputSkew<0).^2./inputUnc(inputSkew<0).^2)-1)./(pi*inputSkew(inputSkew<0).^2./(2*inputUnc(inputSkew<0).^2))).^2);

sigma1=inputUnc./sqrt(1+Gamma);
sigma2=inputUnc./sqrt(1-Gamma);
end
