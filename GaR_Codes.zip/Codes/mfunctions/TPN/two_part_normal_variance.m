function tpnVariance = two_part_normal_variance(sigma1,sigma2)

tpnVariance = (1-2/pi)*(sigma2-sigma1).^2+sigma1.*sigma2;

end