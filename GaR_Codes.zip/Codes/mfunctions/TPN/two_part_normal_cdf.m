function cumulativeDensity = two_part_normal_cdf(x,mode,sigma1,sigma2)
% This function returns the cumulative density function for a two part
% normal density

lessThanMode      = (x<=mode);

cumulativeDensity = ...
    2*sigma1/(sigma1+sigma2)*lessThanMode.*normcdf(x,mode,sigma1) + ...
    (sigma1-sigma2)/(sigma1+sigma2)*(~lessThanMode) +...
    2*sigma2/(sigma1+sigma2)*(~lessThanMode).*normcdf(x,mode,sigma2); 
