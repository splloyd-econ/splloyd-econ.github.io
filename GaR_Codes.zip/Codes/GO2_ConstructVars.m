% GO2_ConstructVars: File to Construct Variables Needed for Estimation
%
% Code to Estimate GDP@Risk with Spillovers
% Edited/Extended Simon Lloyd, Ed Manuel & Konstantin Panchev, April 2021

% CONVENTIONS
% ===========
% A prefix beginning with g denotes GROWTH. (Use 'nperiodgrowth' function 
%   to create)
% A prefix beginning with d denotes CHANGE. 
% The subsequent number denotes the period of growth/change IN QUARTERS
%   --> g1GDP_raw is the 1-quarter growth rate of GDP
%
% A prefix of l denotes a lagged variable. (Use 'createlag' function to
%   create)
%
% As log approx is not always valid (some growth rates >|10%|), all growth
%   rates are constructed using percent change formula (not a log
%   approximation)


% Construct an Intercept
[temp.T,temp.N]     = size(GDP_raw);
Int_raw             = ones(temp.T,temp.N);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TEMPORARY ADDITION
for n = 1:temp.N
    eval([ 'Int' num2str(n) '_raw(:,:) = zeros(temp.T,temp.N);'])
    eval([ 'Int' num2str(n) '_raw(:,n) = ones(temp.T,1);'])
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear temp

% GDP
g1GDP_raw   = nperiodgrowth(GDP_raw,1);
    lg1GDP_raw  = createlag(g1GDP_raw);
g4GDP_raw   = nperiodgrowth(GDP_raw,4);
    lg4GDP_raw  = createlag(g4GDP_raw);
g12GDP_raw  = nperiodgrowth(GDP_raw,12);
    lg1GDP_raw = createlag(g1GDP_raw);    
    
    
% Real-time GDP (UK only)
lRTg1GDP_raw=createlag(RTg1GDP_raw);


% Credit to GDP
d1c2g_raw   = nperiodchange(c2g_raw,1);
d4c2g_raw   = nperiodchange(c2g_raw,4);
d12c2g_raw  = nperiodchange(c2g_raw,12);
    ld12c2g_raw = createlag(d12c2g_raw);
    l2d12c2g_raw = createlag(ld12c2g_raw);

% HH Credit to GDP
d1hhc2g_raw   = nperiodchange(hhc2g_raw,1);
d4hhc2g_raw   = nperiodchange(hhc2g_raw,4);
d12hhc2g_raw  = nperiodchange(hhc2g_raw,12);
    ld12hhc2g_raw = createlag(d12hhc2g_raw);

% PNFC Credit to GDP
d1nfcc2g_raw   = nperiodchange(nfcc2g_raw,1);
d4nfcc2g_raw   = nperiodchange(nfcc2g_raw,4);
d12nfcc2g_raw  = nperiodchange(nfcc2g_raw,12);
    ld12nfcc2g_raw = createlag(d12nfcc2g_raw);

% HP
g1HP_raw   = nperiodgrowth(HP_raw,1);
g4HP_raw   = nperiodgrowth(HP_raw,4);
g12HP_raw  = nperiodgrowth(HP_raw,12);
    lg12HP_raw  = createlag(g12HP_raw);

% Prices
g1pr_raw   = nperiodgrowth(pr_raw,1);
g4pr_raw   = nperiodgrowth(pr_raw,4);
g12pr_raw  = nperiodgrowth(pr_raw,12);
    lg4pr_raw = createlag(g4pr_raw);
   
    
%Interest rates
    ld4ir_raw  = createlag(d4ir_raw);

%Kflows
    lKflowsQA_raw  = createlag(KflowsQA_raw);

%Volatility
	lVIX_raw = createlag(VIX_raw);

