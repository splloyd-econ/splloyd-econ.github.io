% GO6_PlotQuantiles: Plot Coefficients across Quantiles with Swathe for 
% given horizon
%
% Code to Estimate GDP@Risk with Spillovers
% Edited/Extended Simon Lloyd & Ed Manuel, January 2020

%plots
    n=size(X,2)/N;
    f3 = figure; pln=1; 
    nQuantile = length(model.quantiles);
    plotColumns=min(3,n); 
    
for k = (nc+1):n

    subplot(ceil((n-nc)/plotColumns),plotColumns,pln)

    hold on

        %bands 68
       fill([(1:nQuantile), fliplr(1:nQuantile)],...
           [squeeze(model.ub(k,:,hor)) fliplr(squeeze(model.lb(k,:,hor)))],...
           [0.5843 0.8157 0.9882],'EdgeColor','none','MarkerEdgeColor','none', 'FaceAlpha', 0.7);
        
        %zero line
        plot(nQuantile,zeros(nQuantile,1),'color',Ocolor)

        %irfs
        p1=plot(1:nQuantile,squeeze(model.bQRmed(k,:,hor)),'-','LineWidth',1.2,'MarkerSize',2.5,'color',M1color,'MarkerFaceColor',M1color);
        
    hold off; axis tight; grid off
 
    

    xlim([1 nQuantile]);
    set(gca,'XTick',1:1:nQuantile,'XTickLabel',cellstr(num2str(model.quantiles')),'FontSize',8,'layer','top')
    title(varnames{k},'FontSize',9,'FontWeight','Normal')

    pln=pln+1;

    if mod(k,plotColumns)==1

        ylabel('Percentage Points')
    end
    if k>floor((n-1)/plotColumns)*plotColumns

        xlabel('Quantile')        
    end

end

%save chart
set(gcf,'PaperUnits','centimeters','PaperSize',paperSize) %[x y]
set(gcf,'PaperPosition',paperPosition) %[left bottom width height]
