% GO7_PlotIRFOLS: Plot QR and OLS IRFs for given Quantile for Comparison
%
% Code to Estimate GDP@Risk with Spillovers
% Edited/Extended Simon Lloyd & Ed Manuel, January 2020
    
    M1color=[.0 .2 .4];
    Ocolor=[0 0 0];
    paperSize    =[35 50];      %[x y]
    paperPosition=[-2 0 35 50]; %[left bottom width height]

%plots
    n=size(model.X,2)/N;
    f2 = figure; pln=1; 
    nHorizon = max(model.hz);
    plotColumns=min(3,n); 
    
for k = (nc+1):n

    subplot(ceil((n-nc)/plotColumns),plotColumns,pln)

    hold on

        %zero line
        plot(1:nHorizon,zeros(nHorizon,1),'color',Ocolor)

        %irfs
        p1=plot(1:nHorizon,squeeze(model.bQRmed(k,find(quantiles==0.05),:)),'-','LineWidth',1.2,'MarkerSize',2.5,'color',M1color,'MarkerFaceColor',M1color);
        %p1=plot(1:nHorizon,OLS_b(k,:),'-','LineWidth',1.2,'MarkerSize',2.5,'color',M1color,'MarkerFaceColor',M1color);

        % IF you want to overlap the chart with another quantile's media      
        hold on
        
        p2=plot(1:nHorizon,squeeze(model.bQRmed(k,find(quantiles==0.5),:)),'-','LineWidth',1.2,'MarkerSize',2.5,'color','r','MarkerFaceColor','r');
        
           hold on
        
        p3=plot(1:nHorizon,squeeze(model.bQRmed(k,find(quantiles==0.95),:)),'-','LineWidth',1.2,'MarkerSize',2.5,'color','g','MarkerFaceColor','g');   
        
                   hold on
        
        p4=plot(1:nHorizon,model.bOLS(k,:),'-','LineWidth',1.2,'MarkerSize',2.5,'color','m','MarkerFaceColor','m');  

    hold off; axis tight; grid on
 
    

    if k == nc+1 
    legend([p1;p2;p3;p4], '5th percentile', 'median',  '95th percentile', 'OLS', 'Location', 'best');
    else
    
    end
    xlim([1 nHorizon]);
    set(gca,'XTick',2:2:nHorizon,'XTickLabel',cellstr(num2str((2:2:nHorizon)')),'FontSize',8,'layer','top')
    title(varnames{k},'FontSize',9,'FontWeight','Normal')

    pln=pln+1;

    if mod(k,plotColumns)==1

        ylabel('% points')
    end
    if k>floor((n-1)/plotColumns)*plotColumns

        xlabel('horizon')        
    end

end


% %save chart
set(gcf,'PaperUnits','centimeters','PaperSize',paperSize) %[x y]
set(gcf,'PaperPosition',paperPosition) %[left bottom width height]