%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TOOLBOX FOR OPEN MACRO (TOM) 
% ============================
% Codes by Giancarlo Corsetti, Luca Dedola and Simon Lloyd
% 
% Disclaimer: These codes are very preliminary and not to be shared as of
% yet. If you have any questions, suggestions or spot any bugs, please
% contact simon.lloyd@bankofengland.co.uk.
% 
% This version: 0.0, April 2022
% 
% This code: Master file from which everything is run
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc; close all;

% Define the mod file that contains the model codes 
% -------------------------------------------------
modname = 'MasterMod2c.mod';

% Define the name of the experiment that you wish to run
% ------------------------------------------------------
expname = 'Imp_noK'; % Would want to create a folder for the experiment
    
    % Create directory for saving results...
    mkdir(expname);
    % ...and add it to the Matlab path, along with function folder
    addpath(genpath(['./' expname '/']));
    addpath(genpath('./functions/'));

%% DEFINE THE FEATURES OF THE MODELS AND EXPERIMENT
% =========================================================================
% For each model, you can define: financial market structure and inclusion 
% of capital, as well as simulation properties
% (More options to come in later versions, including choice of consumption
% aggregator, addition of roundabout production...)

% Choice of financial market structure
% ------------------------------------
model1.options.FinM         = 'CM';         
    % Options: CM (Complete Markets), FA (Financial Autarky), BE (Bond
    % Economy)

% Choice of including capital in model
% ------------------------------------
model1.options.Cap          = 'No';
    % Options: Yes, No

% Choice of simulation properties
% -------------------------------
model1.options.Sim          = 'First';
    % Options: First (First-Order), Second (Second-Order) [will add
    % simulation and third order)

% Choice of shock to analyse
% --------------------------
model1.options.PlotShock    = 'eps_ZH';

% Choice of parameters that you want to change
% --------------------------------------------
model1.options.params.phiC          = [0.05:0.1:8];

% Define legend entries for plots
% -------------------------------
model1.options.legend               = {'$\phi=0.3$';'$\phi=1.5$';'$\phi=8$'}; % Can define as default if needed

% Choice of variables to plot response of, whether %-dev or change, and 
% their labels in plots
% -------------------------------------------------------------------------
model1.options.PlotVars     = {'YH';'YFs';'RER';'RC';'C';'Cs';'I';'Is';'CHH';'CHF';'IHH';'IHF';'L';'Ls';'R';'Rs'};
model1.options.PlotVarsLabel = {'Home Output';'Foreign Output';'Real Exchange Rate';'Relative Consumption';'Home Consumption';'Foreign Consumption';'Home Investment';'Foreign Investment';'$c^H_{H}$';'$c^H_{F}$';'$i^H_{H}$';'$i^H_{F}$';'Home Labour';'Foreign Labour';'Home Real Interest Rate';'Foreign Real Interest Rate'};

% Choice of whether to plot impulse or impact responses
% -----------------------------------------------------
model1.options.Plot         = 'Impulse';    
    % Options: Impulse (Impulse Response) or Impact (Impact Response)
    
% If impulse repsonse, choose the number of horizons to plot
% ----------------------------------------------------------
model1.options.PlotHor      = 21;           

%% STATE WHICH MODELS YOU WANT TO RUN
% =========================================================================
RunModels = {'model1'};
NM        = length(RunModels);

% Loop over models
for nm = 1:NM
    % Model name
    eval(['model =' char(RunModels{nm}) ';']);
   
    % Define Default parameters
    [model.ss,model.params] = model_definition(model.options);

    % Parse the model
    disp('Parsing the model')
    modrun = ['dynare ' modname  ' -DFinM=' num2str(model.params.iFinM) ' -DCap=' num2str(model.params.iCap)  ' -DSim=' num2str(model.params.iSim) ' noclearall'];
    eval(modrun)

    % Calculate the number of parameter loops
    NP     = length(eval(['model.options.params.' char(model.params.EXP)]));

    % Do the loop and save outputs
    for np = 1:NP
        if strcmp(model.params.EXP,'phiC') == 1
            params.phiC = model.options.params.phiC(np);
            disp(['EOT = ' num2str(model.options.params.phiC(np))])
            set_param_value('phiC',params.phiC);
            if model.params.iCap == 1
                params.phiI = model.options.params.phiC(np);
                set_param_value('phiI',params.phiI);
            end
        else
            eval(['params.' char(model.params.EXP) '= model.options.params.' char(model.params.EXP) '(np);']);
            set_param_value(char(model.params.EXP),eval(['params.' char(model.params.EXP)]));
        end
        
        % Solve a new ss 
        [ssvals, params] = solvesteadystate(params,model.ss);
        for ii = 1:M_.orig_endo_nbr
            var_n = deblank(M_.endo_names(ii,:));
            ssvec = [ssvec; eval(['ssvals.' var_n{1} ';'])];
        end
        oo_.steady_state = ssvec;
        
        %  Simulate the model
        disp('Simulating the model with TFP Shock')
        info = stoch_simul(M_,options_,oo_, var_list_);

        % Extract what you need from Dynare's output
        NV = length(model.options.PlotVars);       
        if strcmp(model.options.Plot,'Impulse') == 1
            for nv = 1:NV
                eval(['model.impulse.' char(model.options.PlotVars{nv}) '_irf(1:model.options.PlotHor,np) = ' char(model.options.PlotVars{nv}) '_' char(model.options.PlotShock) '(1:model.options.PlotHor);'])
            end
        elseif strcmp(model.options.Plot,'Impact') == 1
            for nv = 1:NV
                eval(['model.impact.' char(model.options.PlotVars{nv}) '_imp(1,np) = ' char(model.options.PlotVars{nv}) '_' char(model.options.PlotShock) '(1);'])
            end
        end
        
    % End of loop over params    
    end
    % Model name
    eval([char(RunModels{nm}) '= model;']);
	clear model
% End of loop over models
end
disp('====Model Simulation Complete====');

%% PLOT THE RESULTS
% =========================================================================
% Decide whethere you wish to save figure
% ---------------------------------------
saveFig = 0;

% Loop over models
for nm = 1:NM
    % Model name
    eval(['model =' char(RunModels{nm}) ';']);
    
    % Make plots
    if strcmp(model.options.Plot,'Impulse') == 1
        Plot_Impulse;
    elseif strcmp(model.options.Plot,'Impact') == 1
        Plot_Impact;
    end

    % Save Results
    save(['./' char(expname) '/' char(RunModels{nm})],char(RunModels{nm}));
end
