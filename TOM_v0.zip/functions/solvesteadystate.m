function [ssvals,params]    = solvesteadystate(params,ssinit)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TOOLBOX FOR OPEN MACRO (TOM) 
% ============================
% Codes by Giancarlo Corsetti, Luca Dedola and Simon Lloyd
% 
% Disclaimer: These codes are very preliminary and not to be shared as of
% yet. If you have any questions, suggestions or spot any bugs, please
% contact simon.lloyd@bankofengland.co.uk.
% 
% This version: 0.0, April 2022
% 
% This code: Code to solve for steady state of model
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% SOLVE THE STEADY STATE OF THE MODEL GIVEN THE PARAMETERS IN PARAMS
% NOTE: THE PARAMETERS WILL BE UPDATED TOO TO MATCH STEADY STATE WISHES

%% Fixed Steady States
% =========================================================================
% (2) Home Discount Factor
DF  = params.betta;
% (3) Foreign Discount Factor
DFs = params.bettas;
% (5) Home Euler for Home Bond
R   = 1/params.betta;
% (6) Foreign Euler for Foreign Bond
Rs  = 1/params.bettas;
% (16) Home Endowment
ZH  = params.ZHbar;
% (17) Foreign Endowment 
ZFs = params.ZFsbar;
% (20) Home Current Account
CA  = 0;

% NOTE: we will set BH=0, even under asymmetry! may want to do differently
% (4) Home Bond Position 
BH  = 0;

% Add to SSVALS structure, taking log where necessary to match MOD file
ssvals.DF  = DF;            ssvals.DFs  = DFs;
ssvals.R   = log(R);        ssvals.Rs   = log(Rs);
ssvals.ZH  = log(ZH);       ssvals.ZFs  = log(ZFs);
ssvals.BH  = BH;            ssvals.CA   = CA;
ssvals.TB = 0;

%% Solve remaining model as a system
% =========================================================================
if params.iCap == 1
% If model has capital...
    if nargin == 2
        x0 = [exp(ssinit.C),exp(ssinit.Cs),exp(ssinit.CHH),exp(ssinit.CHF),exp(ssinit.CFH),exp(ssinit.CFF),...
            exp(ssinit.RER),exp(ssinit.TOT),exp(ssinit.PH),exp(ssinit.PFs),exp(ssinit.YH),exp(ssinit.PFs),1,1,...
            exp(ssinit.W),exp(ssinit.Ws),exp(ssinit.RK),exp(ssinit.RKs),exp(ssinit.KH),exp(ssinit.KFs),exp(ssinit.I),exp(ssinit.Is),...
            exp(ssinit.IHH),exp(ssinit.IHF),exp(ssinit.IFH),exp(ssinit.IFF),exp(ssinit.PIH),exp(ssinit.PIFs)];
    else
        % Define initial values (ssvalvec from previous CES solver)
        x0 = [0.27, 0.26, params.aH, params.aF, params.aHs, params.aFs, 1, 1, 1, 1, ...
        0.4, 0.4, 1, 1, 0.8, 0.8, 1/params.betta, 1/params.betta, 0.5, 0.5, 0.12, 0.12, ...
        params.bH, params.bF, params.bHs, params.bFs, 1, 1]';
    end
    
    % solve the thing
    XXX = fsolve(@(XXX) steadystate_k(XXX),x0);

    % Add to SSVALS structure, taking log where necessary to match MOD file
    ssvals.C    = log(XXX(1));    ssvals.Cs   = log(XXX(2));
    ssvals.CHH  = log(XXX(3));    ssvals.CHF  = log(XXX(4));
    ssvals.CFH  = log(XXX(5));    ssvals.CFF  = log(XXX(6));
    ssvals.RER  = log(XXX(7));    ssvals.TOT  = log(XXX(8));
    ssvals.PH   = log(XXX(9));    ssvals.PFs  = log(XXX(10));
    ssvals.YH   = log(XXX(11));   ssvals.YFs  = log(XXX(12));
    params.zl   = (XXX(13));      params.zls  = (XXX(14));
    ssvals.L    = log(params.Lbar); ssvals.Ls = log(params.Lsbar);
    ssvals.W    = log(XXX(15));   ssvals.Ws   = log(XXX(16));
    ssvals.RK   = log(XXX(17));   ssvals.RKs  = log(XXX(18));
    ssvals.KH   = log(XXX(19));   ssvals.KFs  = log(XXX(20));
    ssvals.I    = log(XXX(21));   ssvals.Is   = log(XXX(22));
    ssvals.IHH  = log(XXX(23));   ssvals.IHF  = log(XXX(24));
    ssvals.IFH  = log(XXX(25));   ssvals.IFF  = log(XXX(26));
    ssvals.PIH  = log(XXX(27));   ssvals.PIFs = log(XXX(28));

else
% If model has no capital...
    if nargin == 2
        x0 = [exp(ssinit.C),exp(ssinit.Cs),exp(ssinit.CHH),exp(ssinit.CHF),exp(ssinit.CFH),exp(ssinit.CFF),...
            exp(ssinit.RER),exp(ssinit.TOT),exp(ssinit.PH),exp(ssinit.PFs),exp(ssinit.YH),exp(ssinit.PFs),1,1,...
            exp(ssinit.W),exp(ssinit.Ws)];
    else
        x0 = [0.25, 0.25, params.aH, params.aF, params.aHs, params.aFs, 1, 1, 1, 1, ...
            0.4, 0.4, 1, 1, 0.8, 0.8]';
    end
    
    % solve the thing
    XXX = fsolve(@(XXX) steadystate_no_k(XXX),x0);

    % Add to SSVALS structure, taking log where necessary to match MOD file
    ssvals.C    = log(XXX(1));    ssvals.Cs   = log(XXX(2));
    ssvals.CHH  = log(XXX(3));    ssvals.CHF  = log(XXX(4));
    ssvals.CFH  = log(XXX(5));    ssvals.CFF  = log(XXX(6));
    ssvals.RER  = log(XXX(7));    ssvals.TOT  = log(XXX(8));
    ssvals.PH   = log(XXX(9));    ssvals.PFs  = log(XXX(10));
    ssvals.YH   = log(XXX(11));   ssvals.YFs  = log(XXX(12));
    params.zl   = (XXX(13));      params.zls  = (XXX(14));
    ssvals.L    = log(params.Lbar); ssvals.Ls = log(params.Lsbar);
    ssvals.W    = log(XXX(15));   ssvals.Ws   = log(XXX(16));
end
% (18) Relative Consumption
ssvals.RC = log(XXX(1)/XXX(2));

%% Update PARAMS with calibrated parameters

% (2) Home Uzawa Discount Factor
params.omeg     = (DF)/(XXX(1)^(-params.uz));
% (3) Foreign Uzawa Discount Factor
params.omegs    = (DFs)/(XXX(2)^(-params.uzs));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% System of equations for model with capital
function F = steadystate_k(XXX) 

    C   = XXX(1);     Cs  = XXX(2);
    CHH = XXX(3);     CHF = XXX(4);
    CFH = XXX(5);     CFF = XXX(6);
    RER = XXX(7);     TOT = XXX(8);
    PH  = XXX(9);     PFs = XXX(10);
    YH  = XXX(11);    YFs = XXX(12);
    zl  = XXX(13);    zls = XXX(14);
    W   = XXX(15);    Ws  = XXX(16);
    RK  = XXX(17);    RKs = XXX(18);
    KH  = XXX(19);    KFs = XXX(20);
    I   = XXX(21);    Is  = XXX(22);
    IHH = XXX(23);    IHF = XXX(24);
    IFH = XXX(25);    IFF = XXX(26);
    PIH = XXX(27);    PIFs= XXX(28);
        
    %% Common equations
    if params.iFinM == 1
        % (1) Risk Sharing: Complete Markets
        eq1 = ((C)/(Cs))^(-params.sig)*(RER) - 1;
    end
    if params.iFinM == 2
        % (1) Trade Balance
        eq1 = TOT*(CHF+IHF) - CFH - IFH;
    end
    if params.iFinM == 3
        % (1) Home Budget Constraint
        eq1 = PH*YH - C - PIH*I;
    end
    % (11) Home Consumption Price Index
    eq2 = (C) - ( (PH)*(CHH) + (RER)*(PFs)*(CHF) );
    % (12) Foreign Consumption Price Index
    eq3 = (Cs) - ( (PH)*(CFH)/(RER) + (PFs)*(CFF) );
    % (11) Home Investment Price Index
    eq4 = PIH*(I) - ( (PH)*(IHH) + (RER)*(PFs)*(IHF) );
    % (12) Foreign Investment Price Index
    eq5 = PIFs*(Is) - ( (PH)*(IFH)/(RER) + (PFs)*(IFF) );
    
    % (13) Terms of Trade
    eq6 = (TOT) - ( (RER)*(PFs)/(PH) );
    % (14) Home Goods Market Equilibrium
    eq7 = YH - (CHH + CFH + IHH + IFH);
    % (15) Foreign Goods Market Equilibrium
    eq8 = YFs - (CHF + CFF + IHF + IFF);

    % (7) Home Investment Decision
    eq9 = 1 - (params.betta*(1/PIH)*(RK + PIH*(1-params.delta)));
    % (8) Foreign Investment Decision
    eq10 = 1 - (params.bettas*(1/PIFs)*(RKs + PIFs*(1-params.deltas)));
    
    % (17) Home Intratemporal Labour Choice
    eq11 = (zl*(params.Lbar^(1/params.ps)) - (C^(-params.sig))*W);
    % (18) Foreign Intratemporal Labour Choice
    eq12 = (zls*(params.Lsbar^(1/params.pss)) - (Cs^(-params.sigs))*Ws);

    % (19) Home Tradables Production Function
    eq13 = YH - (params.ZHbar*(KH^(1-params.xi))*(params.Lbar^(params.xi)));
    % (20) Home Labour Demand
    eq14 = W*params.Lbar - (params.xi*PH*YH);
    % (21) Home Capital Demand
    eq15 = RK*KH - ((1-params.xi)*PH*YH);
    % (22) Home Capital Evolution
    eq16 = KH - (I + (1-params.delta)*KH);

    % (23) Foreign Tradables Production Function
    eq17 = YFs - (params.ZFsbar*(KFs^(1-params.xis))*(params.Lsbar^(params.xis)));
    % (24) Foreign Labour Demand
    eq18 = Ws*params.Lsbar - (params.xis*PFs*YFs);
    % (25) Foreign Capital Demand
    eq19 = RKs*KFs - ((1-params.xis)*PFs*YFs);
    % (26) Foreign Capital Evolution
    eq20 = KFs - (Is + (1-params.deltas)*KFs);

    %% AGGREGATOR-SPECIFIC BLOCK
        %% CES AGGREGATOR
        % ====================================================================
        % General CES Form
        % (7) Home Aggregate Consumption
        eq21 = (C)  - ((params.aH^(1/params.phiC))*((CHH)^((params.phiC-1)/params.phiC)) + (params.aF^(1/params.phiC))*((CHF)^((params.phiC-1)/params.phiC)))^(params.phiC/(params.phiC-1));
        % (8) Foreign Aggregate Consumption
        eq22 = (Cs) - ((params.aHs^(1/params.phiC))*((CFH)^((params.phiC-1)/params.phiC)) + (params.aFs^(1/params.phiC))*((CFF)^((params.phiC-1)/params.phiC)))^(params.phiC/(params.phiC-1));

        % (7) Home Aggregate Investment
        eq23 = (I)  - ((params.bH^(1/params.phiI))*((IHH)^((params.phiI-1)/params.phiI)) + (params.bF^(1/params.phiI))*((IHF)^((params.phiI-1)/params.phiI)))^(params.phiI/(params.phiI-1));
        % (8) Foreign Aggregate Investment
        eq24 = (Is) - ((params.bHs^(1/params.phiI))*((IFH)^((params.phiI-1)/params.phiI)) + (params.bFs^(1/params.phiI))*((IFF)^((params.phiI-1)/params.phiI)))^(params.phiI/(params.phiI-1));

        % (9) Home Relative Consumption Demand
        eq25 = (CHH)/(CHF) - (params.aH/params.aF)*((1/(TOT))^(-params.phiC));
        % (10) Foreign Relative Consumption Demand
        eq26 = (CFH)/(CFF) - (params.aHs/params.aFs)*((1/(TOT))^(-params.phiC));

        % (9) Home Relative Investment Demand
        eq27 = (IHH)/(IHF) - (params.bH/params.bF)*((1/(TOT))^(-params.phiI));
        % (10) Foreign Relative Investment Demand
        eq28 = (IFH)/(IFF) - (params.bHs/params.bFs)*((1/(TOT))^(-params.phiI));
        
    %% Create system of eqns
    F = [eq1; eq2; eq3; eq4; eq5; eq6; eq7; eq8; eq9; eq10; eq11; eq12; ...
        eq13; eq14; eq15; eq16; eq17; eq18; eq19; eq20; eq21; eq22; eq23; eq24; ...
        eq25; eq26; eq27; eq28];        
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% System of equations for model with no capital
function F = steadystate_no_k(XXX) 

    C   = XXX(1);     Cs  = XXX(2);
    CHH = XXX(3);     CHF = XXX(4);
    CFH = XXX(5);     CFF = XXX(6);
    RER = XXX(7);     TOT = XXX(8);
    PH  = XXX(9);     PFs = XXX(10);
    YH  = XXX(11);    YFs = XXX(12);
    zl  = XXX(13);    zls = XXX(14);
    W   = XXX(15);    Ws  = XXX(16);
        
    %% Common equations
    if params.iFinM == 1
        % (1) Risk Sharing: Complete Markets
        eq1 = ((C)/(Cs))^(-params.sig)*(RER) - 1;
    end
    if params.iFinM == 2
        % (1) Trade Balance
        eq1 = TOT*(CHF) - CFH;
    end
    if params.iFinM == 3
        % (1) Home Budget Constraint
        eq1 = PH*YH - C;
    end
    % (11) Home Consumption Price Index
    eq2 = (C) - ( (PH)*(CHH) + (RER)*(PFs)*(CHF) );
    % (12) Foreign Consumption Price Index
    eq3 = (Cs) - ( (PH)*(CFH)/(RER) + (PFs)*(CFF) );
    
    % (13) Terms of Trade
    eq4 = (TOT) - ( (RER)*(PFs)/(PH) );
    % (14) Home Goods Market Equilibrium
    eq5 = YH - (CHH + CFH);
    % (15) Foreign Goods Market Equilibrium
    eq6 = YFs - (CHF + CFF);

    % (17) Home Intratemporal Labour Choice
    eq7 = (zl*(params.Lbar^(1/params.ps)) - (C^(-params.sig))*W);
    % (18) Foreign Intratemporal Labour Choice
    eq8 = (zls*(params.Lsbar^(1/params.pss)) - (Cs^(-params.sigs))*Ws);

    % (19) Home Tradables Production Function
    eq9 = YH - (params.ZHbar*(params.Lbar^(params.xi)));
    % (20) Home Labour Demand
    eq10 = W*params.Lbar - (params.xi*PH*YH);
    
    % (23) Foreign Tradables Production Function
    eq11 = YFs - (params.ZFsbar*(params.Lsbar^(params.xis)));
    % (24) Foreign Labour Demand
    eq12 = Ws*params.Lsbar - (params.xis*PFs*YFs);
    
    %% AGGREGATOR-SPECIFIC BLOCK
        %% CES AGGREGATOR
        % ====================================================================
        % General CES Form
        % (7) Home Aggregate Consumption
        eq13 = (C)  - ((params.aH^(1/params.phiC))*((CHH)^((params.phiC-1)/params.phiC)) + (params.aF^(1/params.phiC))*((CHF)^((params.phiC-1)/params.phiC)))^(params.phiC/(params.phiC-1));
        % (8) Foreign Aggregate Consumption
        eq14 = (Cs) - ((params.aHs^(1/params.phiC))*((CFH)^((params.phiC-1)/params.phiC)) + (params.aFs^(1/params.phiC))*((CFF)^((params.phiC-1)/params.phiC)))^(params.phiC/(params.phiC-1));

        % (9) Home Relative Consumption Demand
        eq15 = (CHH)/(CHF) - (params.aH/params.aF)*((1/(TOT))^(-params.phiC));
        % (10) Foreign Relative Consumption Demand
        eq16 = (CFH)/(CFF) - (params.aHs/params.aFs)*((1/(TOT))^(-params.phiC));

    %% Create system of eqns
    F = [eq1; eq2; eq3; eq4; eq5; eq6; eq7; eq8; eq9; eq10; eq11; eq12; ...
        eq13; eq14; eq15; eq16];        
end
end