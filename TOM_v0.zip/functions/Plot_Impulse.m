%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TOOLBOX FOR OPEN MACRO (TOM) 
% ============================
% Codes by Giancarlo Corsetti, Luca Dedola and Simon Lloyd
% 
% Disclaimer: These codes are very preliminary and not to be shared as of
% yet. If you have any questions, suggestions or spot any bugs, please
% contact simon.lloyd@bankofengland.co.uk.
% 
% This version: 0.0, April 2022
% 
% This code: Code to plot impulse response functions
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Setup a few things for plotting
setup_lumap;    % Run bespoke colour map
set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultLegendInterpreter','latex');

% Refresh Indices
NV = length(model.options.PlotVars);       
NP = length(eval(['model.options.params.' char(model.params.EXP)]));

% Define Axes and Plot Size
xax = [0:1:model.options.PlotHor-1];
col = 4; 
row = ceil(NV/col); % this must be an integer!

% Figure
f1 = figure('units','normalized','position',[0.05 0.01 0.9 0.9]);
for nv = 1:NV
   subplot(row,col,nv)
   for np = 1:NP
	  toplot_ = eval(['model.impulse.' char(model.options.PlotVars{nv}) '_irf(:,np)']);
	  s = plot(xax,toplot_,'LineWidth',2,'Color',lumap(np,:)); hold on;
      if np==2
          s.LineStyle = '--';
      elseif np==3
          s.LineStyle = ':';
      elseif np==3
          s.LineStyle = '-.';    
      end
   end
   plot(xax,zeros(model.options.PlotHor,1),'k','LineWidth',0.5); hold off;
   title(model.options.PlotVarsLabel{nv},'Interpreter','latex','FontSize',16);
   set(gca,'FontSize',14);
   if nv == NV
	   l = legend(model.options.legend);
       l.Interpreter = 'latex';
       l.Location = 'best';
   end
   
end
if saveFig == 1
    saveas(f1,['./' char(expname) '/' char(RunModels{nm}) '_IRF.png'],'png');
    saveas(f1,['./' char(expname) '/' char(RunModels{nm}) '_IRF.eps'],'epsc');
end
