function [ssvals,params] = model_definition(options)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TOOLBOX FOR OPEN MACRO (TOM) 
% ============================
% Codes by Giancarlo Corsetti, Luca Dedola and Simon Lloyd
% 
% Disclaimer: These codes are very preliminary and not to be shared as of
% yet. If you have any questions, suggestions or spot any bugs, please
% contact simon.lloyd@bankofengland.co.uk.
% 
% This version: 0.0, April 2022
% 
% This code: Code to define the model structure
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Define the switches based on defined options
% =========================================================================
if strcmp(options.FinM,'CM') == 1
    params.iFinM = 1;
elseif strcmp(options.FinM,'FA') == 1
    params.iFinM = 2;
elseif  strcmp(options.FinM,'BE') == 1
    params.iFinM = 3;
else
    disp('Please choose a valid fin. mkt. structure: CE, FA, BE');
end

if strcmp(options.Cap,'Yes') == 1
    params.iCap = 1;
elseif strcmp(options.Cap,'No') == 1
    params.iCap = 0;
else 
    disp('Please choose valid capital option: Yes, No');
end

if strcmp(options.Sim,'First') == 1
    params.iSim = 1;
elseif strcmp(options.Sim,'Second') == 1
    params.iSim = 2;
elseif strcmp(options.Sim,'Simul') == 1
    params.iSim = 0;
else
    disp('Please choose valid simulation option: Simul, First, Second');
end

if strcmp(options.Plot,'Impulse') == 1
    params.iPlot = 1;
elseif strcmp(options.Plot,'Impact') == 1
    params.iPlot = 0;
else
    disp('Please choose a valid plotting option: Impulse, Impact');
end

%% Define parameters
parameterisation;

%% solve steady state with these parameters
[ssvals,params] = solvesteadystate(params);

%% Define the parameter that is being varied in experiments
params.EXP = fieldnames(options.params);
params.EXPVALS = eval(['options.params.' char(params.EXP)]);

%% Define the shock processes
if options.PlotShock == 'eps_ZH'
    shocks_active_ = [1;0];    
elseif options.PlotShock == 'eps_ZFs'
    shocks_active_ = [0;1];
else
    disp('Please choose valid shock option: eps_ZH, eps_ZFs');
end
params.sig_z     = shocks_active_(1)*0.01*((1-params.rhoZH^2))^.5;       
params.sig_zs    = shocks_active_(2)*0.01*((1-params.rhoZFs^2))^.5;

save PARAMS params
save STEADYSTATE ssvals

end