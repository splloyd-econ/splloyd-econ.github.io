%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TOOLBOX FOR OPEN MACRO (TOM) 
% ============================
% Codes by Giancarlo Corsetti, Luca Dedola and Simon Lloyd
% 
% Disclaimer: These codes are very preliminary and not to be shared as of
% yet. If you have any questions, suggestions or spot any bugs, please
% contact simon.lloyd@bankofengland.co.uk.
% 
% This version: 0.0, April 2022
% 
% This code: Code to plot impact response functions
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Setup a few things for plotting
setup_lumap;    % Run bespoke colour map
set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultLegendInterpreter','latex');

% Refresh Indices
NV = length(model.options.PlotVars);       
NP = length(eval(['model.options.params.' char(model.params.EXP)]));

% Define Axes and Plot Size
xax = eval(['model.options.params.' char(model.params.EXP)]);
col = 4; 
row = ceil(NV/col); % this must be an integer!

% Figure
f1 = figure('units','normalized','position',[0.05 0.01 0.9 0.9]);
for nv = 1:NV
    subplot(row,col,nv)
    toplot_ = eval(['model.impact.' char(model.options.PlotVars{nv}) '_imp(1,:)']);
    s = plot(xax,transpose(toplot_),'LineWidth',2,'Color',lumap(1,:)); hold on;
    plot(xax,zeros(length(xax),1),'k','LineWidth',0.5); hold off;
    title(model.options.PlotVarsLabel{nv},'Interpreter','latex','FontSize',16);
    set(gca,'FontSize',14);
end
if saveFig == 1
    saveas(f1,['./' char(expname) '/' char(RunModels{nm}) '_Impact.png'],'png');
    saveas(f1,['./' char(expname) '/' char(RunModels{nm}) '_Impact.eps'],'epsc');
end
