%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TOOLBOX FOR OPEN MACRO (TOM) 
% ============================
% Codes by Giancarlo Corsetti, Luca Dedola and Simon Lloyd
% 
% Disclaimer: These codes are very preliminary and not to be shared as of
% yet. If you have any questions, suggestions or spot any bugs, please
% contact simon.lloyd@bankofengland.co.uk.
% 
% This version: 0.0, April 2022
% 
% This code: Code to parameter values for the model
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Deep parameters
params.betta   = 0.99;
params.bettas  = params.betta;
params.uz      = 0.01;
params.uzs     = params.uz;
params.sig     = 2;
params.sigs    = params.sig;
params.rhoZH   = 0.96;
params.rhoZFs  = params.rhoZH; 
params.ZHbar   = 1;
params.ZFsbar  = 1;

%% Additional deep parameters for production model
params.ps      = 0.5;
params.pss     = params.ps;
params.delta   = 0.025;
params.deltas  = params.delta;
params.xi      = 2/3;
params.xis     = params.xi;

% We'll also calibrate zl(s) to match a SS time spent on labour of 1/3
% i.e. solver treats zl(s) as variable, and all L(s) replaced by
% params.L(s)bar. In Output, zl(s) still stored as params, and an
% ssvals.L(s) also defined based on params.L(s)bar
params.Lbar    = 1/3;   % Steady state labour supply target
params.Lsbar   = 1/3;   % Steady state labour supply target

%% CES parameters - these are effectively our steady state targets
params.phiC    = 1.5; 
params.phiI    = params.phiC;
params.aH      = 0.8;
params.aF      = 1-params.aH;
params.aFs     = params.aH;
params.aHs     = 1-params.aFs;
params.bH      = 0.8;
params.bF      = 1-params.bH;
params.bFs     = params.bH;
params.bHs     = 1-params.bFs;

params.Ces = 1;
if params.phiC==1
    params.Ces = 0;
end
